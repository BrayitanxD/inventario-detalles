<?php
$pageTitle = 'Catálogo de Productos - Peluches & Detalles';
require_once __DIR__ . '/../layouts/header.php';
?>

<!-- Encabezado y Acciones -->
<div class="d-flex flex-wrap justify-content-between align-items-center mb-4 gap-3">
    <div>
        <h3 class="fw-bold text-dark mb-1">Catálogo de Productos</h3>
        <p class="text-muted small mb-0">Gestión de peluches, anchetas, globos, chocolates y accesorios.</p>
    </div>
    <div class="d-flex gap-2">
        <a href="<?= url('movimiento', 'entradas') ?>" class="btn btn-outline-success btn-sm d-flex align-items-center gap-1">
            <i class="bi bi-box-arrow-in-down"></i> Entradas / Compras
        </a>
        <button class="btn btn-pink btn-sm d-flex align-items-center gap-1 fw-semibold shadow-sm" onclick="abrirModalCrear()">
            <i class="bi bi-plus-lg"></i> Nuevo Producto
        </button>
    </div>
</div>

<!-- Barra de Resumen de Inventario -->
<div class="row g-3 mb-4">
    <div class="col-6 col-md-3">
        <div class="card border-0 shadow-sm p-3">
            <span class="text-muted extra-small fw-semibold">Productos Registrados</span>
            <h5 class="fw-bold mb-0 text-dark"><?= $estadisticas['total_productos'] ?></h5>
        </div>
    </div>
    <div class="col-6 col-md-3">
        <div class="card border-0 shadow-sm p-3">
            <span class="text-muted extra-small fw-semibold">Unidades Físicas</span>
            <h5 class="fw-bold mb-0 text-dark"><?= number_format($estadisticas['total_unidades'] ?? 0) ?></h5>
        </div>
    </div>
    <div class="col-6 col-md-3">
        <div class="card border-0 shadow-sm p-3">
            <span class="text-muted extra-small fw-semibold">Valor al Costo</span>
            <h5 class="fw-bold mb-0 text-secondary"><?= formatPrice($estadisticas['total_valor_costo'] ?? 0) ?></h5>
        </div>
    </div>
    <div class="col-6 col-md-3">
        <div class="card border-0 shadow-sm p-3">
            <span class="text-muted extra-small fw-semibold">Valoración a la Venta</span>
            <h5 class="fw-bold mb-0 text-primary"><?= formatPrice($estadisticas['total_valor_venta'] ?? 0) ?></h5>
        </div>
    </div>
</div>

<!-- Filtros de Búsqueda -->
<div class="card border-0 shadow-sm mb-4">
    <div class="card-body p-3">
        <form method="GET" action="<?= BASE_URL ?>/index.php" class="row g-2 align-items-center">
            <input type="hidden" name="c" value="producto">
            <input type="hidden" name="a" value="index">

            <div class="col-md-5">
                <div class="input-group input-group-sm">
                    <span class="input-group-text bg-light"><i class="bi bi-search"></i></span>
                    <input type="text" name="q" class="form-control" placeholder="Buscar por nombre, código de barras..." value="<?= htmlspecialchars($busqueda ?? '') ?>">
                </div>
            </div>

            <div class="col-md-4">
                <select name="categoria_id" class="form-select form-select-sm" onchange="this.form.submit()">
                    <option value="">Todas las Categorías</option>
                    <?php foreach ($categorias as $cat): ?>
                        <option value="<?= $cat['id'] ?>" <?= ($categoriaId == $cat['id']) ? 'selected' : '' ?>>
                            <?= htmlspecialchars($cat['nombre']) ?> (<?= $cat['total_productos'] ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="col-md-3 d-flex gap-2">
                <button type="submit" class="btn btn-dark btn-sm flex-grow-1">Filtrar</button>
                <?php if (!empty($busqueda) || !empty($categoriaId)): ?>
                    <a href="<?= url('producto', 'index') ?>" class="btn btn-outline-secondary btn-sm" title="Limpiar Filtros">
                        <i class="bi bi-x-circle"></i>
                    </a>
                <?php endif; ?>
            </div>
        </form>
    </div>
</div>

<!-- Tabla de Productos -->
<div class="card border-0 shadow-sm">
    <div class="table-responsive">
        <table class="table align-middle mb-0 table-hover">
            <thead class="table-light extra-small text-uppercase text-muted">
                <tr>
                    <th style="width: 60px;">Foto</th>
                    <th>Código</th>
                    <th>Producto</th>
                    <th>Categoría</th>
                    <th>Costo</th>
                    <th>P. Venta</th>
                    <th>Margen</th>
                    <th>Stock</th>
                    <th>Ubicación</th>
                    <th class="text-end pe-3">Acciones</th>
                </tr>
            </thead>
            <tbody class="small">
                <?php if (empty($productos)): ?>
                    <tr>
                        <td colspan="10" class="text-center py-5 text-muted">
                            <i class="bi bi-box-seam fs-1 text-muted d-block mb-2"></i>
                            No se encontraron productos en el inventario.
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($productos as $p): ?>
                        <?php 
                            $costo = (float)$p['precio_compra'];
                            $venta = (float)$p['precio_venta'];
                            $margenPorc = ($costo > 0) ? round((($venta - $costo) / $costo) * 100, 1) : 0;
                            $stockCritico = $p['stock_actual'] <= $p['stock_minimo'];
                            $imgSrc = !empty($p['imagen']) ? asset($p['imagen']) : 'https://placehold.co/50x50/fdf2f8/ec4899?text=P';
                        ?>
                        <tr>
                            <td>
                                <img src="<?= $imgSrc ?>" alt="<?= htmlspecialchars($p['nombre']) ?>" class="rounded-3" style="width: 45px; height: 45px; object-fit: cover;">
                            </td>
                            <td class="text-muted extra-small fw-mono">
                                <?= htmlspecialchars($p['codigo_barras'] ?? 'S/C') ?>
                            </td>
                            <td>
                                <div class="fw-bold text-dark"><?= htmlspecialchars($p['nombre']) ?></div>
                                <?php if (!empty($p['descripcion'])): ?>
                                    <small class="text-muted text-truncate d-inline-block" style="max-width: 220px;"><?= htmlspecialchars($p['descripcion']) ?></small>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="badge bg-light text-secondary border"><?= htmlspecialchars($p['categoria_nombre']) ?></span>
                            </td>
                            <td class="text-muted"><?= formatPrice($p['precio_compra']) ?></td>
                            <td class="fw-bold text-primary"><?= formatPrice($p['precio_venta']) ?></td>
                            <td>
                                <span class="badge bg-success-subtle text-success">+<?= $margenPorc ?>%</span>
                            </td>
                            <td>
                                <span class="badge <?= $stockCritico ? 'bg-danger' : 'bg-success' ?> rounded-pill px-2">
                                    <?= $p['stock_actual'] ?> u.
                                </span>
                                <?php if ($stockCritico): ?>
                                    <div class="extra-small text-danger mt-1">Mín: <?= $p['stock_minimo'] ?></div>
                                <?php endif; ?>
                            </td>
                            <td class="text-muted extra-small"><?= htmlspecialchars($p['ubicacion'] ?? 'Mostrador') ?></td>
                            <td class="text-end pe-3">
                                <button class="btn btn-outline-primary btn-sm py-1 px-2 me-1" onclick='abrirModalEditar(<?= json_encode($p) ?>)' title="Editar">
                                    <i class="bi bi-pencil-square"></i>
                                </button>
                                <?php if (($_SESSION['user']['rol'] ?? '') === 'admin'): ?>
                                    <form method="POST" action="<?= url('producto', 'eliminar') ?>" class="d-inline" onsubmit="confirmarAccion(event, '¿Eliminar producto?', 'El producto no estará disponible para ventas ni catálogo.')">
                                        <input type="hidden" name="id" value="<?= $p['id'] ?>">
                                        <button type="submit" class="btn btn-outline-danger btn-sm py-1 px-2" title="Eliminar">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Modal para Crear / Editar Producto -->
<div class="modal fade" id="productoModal" tabindex="-1">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content border-0 shadow">
            <div class="modal-header bg-dark-navy text-white">
                <h5 class="modal-title fw-bold" id="productoModalTitle">Nuevo Producto</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" action="<?= url('producto', 'guardar') ?>" enctype="multipart/form-data" id="productoForm">
                <input type="hidden" name="id" id="prodId">
                <div class="modal-body p-4">
                    <div class="row g-3">
                        <div class="col-md-8">
                            <label class="form-label small fw-semibold">Nombre del Producto *</label>
                            <input type="text" name="nombre" id="prodNombre" class="form-control" placeholder="Ej: Oso Gigante 1m Crema con Moño" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label small fw-semibold">Código de Barras / SKU</label>
                            <input type="text" name="codigo_barras" id="prodCodigo" class="form-control" placeholder="7701001">
                        </div>

                        <div class="col-md-6">
                            <label class="form-label small fw-semibold">Categoría *</label>
                            <select name="categoria_id" id="prodCategoria" class="form-select" required>
                                <option value="">Selecciona una categoría...</option>
                                <?php foreach ($categorias as $cat): ?>
                                    <option value="<?= $cat['id'] ?>"><?= htmlspecialchars($cat['nombre']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label small fw-semibold">Ubicación en Tienda / Bodega</label>
                            <input type="text" name="ubicacion" id="prodUbicacion" class="form-control" placeholder="Ej: Estante A2, Nevera, Bodega B">
                        </div>

                        <div class="col-md-6">
                            <label class="form-label small fw-semibold">Precio de Compra (Costo) *</label>
                            <div class="input-group">
                                <span class="input-group-text">$</span>
                                <input type="number" step="100" min="0" name="precio_compra" id="prodPrecioCompra" class="form-control" placeholder="45000" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label small fw-semibold">Precio de Venta al Público *</label>
                            <div class="input-group">
                                <span class="input-group-text">$</span>
                                <input type="number" step="100" min="0" name="precio_venta" id="prodPrecioVenta" class="form-control" placeholder="85000" required>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <label class="form-label small fw-semibold">Stock Inicial / Físico *</label>
                            <input type="number" min="0" name="stock_actual" id="prodStock" class="form-control" value="0" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label small fw-semibold">Stock Mínimo (Alerta) *</label>
                            <input type="number" min="1" name="stock_minimo" id="prodStockMin" class="form-control" value="5" required>
                        </div>

                        <div class="col-12">
                            <label class="form-label small fw-semibold">Descripción o Detalles del Producto</label>
                            <textarea name="descripcion" id="prodDescripcion" class="form-control" rows="2" placeholder="Material antialérgico, incluye moño, temática san valentín..."></textarea>
                        </div>

                        <div class="col-12">
                            <label class="form-label small fw-semibold">Foto del Producto (Opcional)</label>
                            <input type="file" name="imagen" class="form-control" accept="image/*">
                        </div>
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-pink fw-semibold">Guardar Producto</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    const modalEl = document.getElementById('productoModal');
    let bsModal;

    function getModalInstance() {
        if (!bsModal) {
            bsModal = new bootstrap.Modal(modalEl);
        }
        return bsModal;
    }

    function abrirModalCrear() {
        document.getElementById('productoForm').reset();
        document.getElementById('prodId').value = '';
        document.getElementById('productoModalTitle').innerText = 'Nuevo Producto';
        getModalInstance().show();
    }

    function abrirModalEditar(prod) {
        document.getElementById('productoForm').reset();
        document.getElementById('prodId').value = prod.id;
        document.getElementById('prodNombre').value = prod.nombre;
        document.getElementById('prodCodigo').value = prod.codigo_barras || '';
        document.getElementById('prodCategoria').value = prod.categoria_id;
        document.getElementById('prodUbicacion').value = prod.ubicacion || '';
        document.getElementById('prodPrecioCompra').value = prod.precio_compra;
        document.getElementById('prodPrecioVenta').value = prod.precio_venta;
        document.getElementById('prodStock').value = prod.stock_actual;
        document.getElementById('prodStock').readOnly = true; // El stock se modifica por compras/mermas
        document.getElementById('prodStockMin').value = prod.stock_minimo;
        document.getElementById('prodDescripcion').value = prod.descripcion || '';
        document.getElementById('productoModalTitle').innerText = 'Editar Producto';
        getModalInstance().show();
    }
</script>

<?php require_once __DIR__ . '/../layouts/footer.php'; ?>
