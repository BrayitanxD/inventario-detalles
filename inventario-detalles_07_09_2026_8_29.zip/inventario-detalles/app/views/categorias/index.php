<?php
$pageTitle = 'Categorías - Peluches & Detalles';
require_once __DIR__ . '/../layouts/header.php';
?>

<div class="d-flex flex-wrap justify-content-between align-items-center mb-4 gap-3">
    <div>
        <h3 class="fw-bold text-dark mb-1">Categorías de la Tienda</h3>
        <p class="text-muted small mb-0">Organización del inventario en peluches, anchetas, globos, chocolates y accesorios.</p>
    </div>
    <button class="btn btn-pink btn-sm d-flex align-items-center gap-1 fw-semibold shadow-sm" onclick="abrirModalCategoria()">
        <i class="bi bi-plus-lg"></i> Nueva Categoría
    </button>
</div>

<div class="row g-4">
    <div class="col-lg-8">
        <div class="card border-0 shadow-sm">
            <div class="table-responsive">
                <table class="table align-middle mb-0 table-hover">
                    <thead class="table-light extra-small text-uppercase text-muted">
                        <tr>
                            <th>#</th>
                            <th>Nombre</th>
                            <th>Descripción</th>
                            <th>Productos Asociados</th>
                            <th class="text-end pe-3">Acciones</th>
                        </tr>
                    </thead>
                    <tbody class="small">
                        <?php if (empty($categorias)): ?>
                            <tr>
                                <td colspan="5" class="text-center py-4 text-muted">No hay categorías creadas.</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($categorias as $cat): ?>
                                <tr>
                                    <td class="text-muted"><?= $cat['id'] ?></td>
                                    <td class="fw-bold text-dark"><?= htmlspecialchars($cat['nombre']) ?></td>
                                    <td class="text-muted"><?= htmlspecialchars($cat['descripcion'] ?? 'Sin descripción') ?></td>
                                    <td>
                                        <span class="badge bg-primary-subtle text-primary"><?= $cat['total_productos'] ?> productos</span>
                                    </td>
                                    <td class="text-end pe-3">
                                        <button class="btn btn-outline-primary btn-sm py-1 px-2 me-1" onclick='editarCategoria(<?= json_encode($cat) ?>)'>
                                            <i class="bi bi-pencil-square"></i>
                                        </button>
                                        <?php if (($_SESSION['user']['rol'] ?? '') === 'admin'): ?>
                                            <form method="POST" action="<?= url('categoria', 'eliminar') ?>" class="d-inline" onsubmit="confirmarAccion(event, '¿Eliminar categoría?', 'No se eliminarán los productos, pero quedarán sin esta categoría.')">
                                                <input type="hidden" name="id" value="<?= $cat['id'] ?>">
                                                <button type="submit" class="btn btn-outline-danger btn-sm py-1 px-2">
                                                    <i class="bi bi-trash"></i>
                                                </button>
                                            </form>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Panel lateral con ideas de categorías -->
    <div class="col-lg-4">
        <div class="card border-0 shadow-sm p-4 bg-white">
            <h6 class="fw-bold text-dark mb-3"><i class="bi bi-lightbulb text-warning me-2"></i>Estructura recomendada</h6>
            <p class="small text-muted mb-3">
                Para negocios de peluches y detalles, recomendamos separar claramente:
            </p>
            <ul class="small text-muted ps-3 mb-0">
                <li class="mb-2"><strong>Peluches:</strong> Por tamaño o tipo (Gigantes, Pequeños, Llaveros, Temáticos).</li>
                <li class="mb-2"><strong>Globos y Helio:</strong> Insumos de decoración y arreglos flotantes.</li>
                <li class="mb-2"><strong>Chocolatería:</strong> Bombones, chocolates de marca, dulces para anchetas.</li>
                <li class="mb-2"><strong>Cajas y Empaques:</strong> Madera, cartón rígido, papel seda, moños.</li>
                <li><strong>Anchetas Listas:</strong> Arreglos armados listos para entregar.</li>
            </ul>
        </div>
    </div>
</div>

<!-- Modal Categoría -->
<div class="modal fade" id="categoriaModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow">
            <div class="modal-header bg-dark-navy text-white">
                <h5 class="modal-title fw-bold" id="catModalTitle">Nueva Categoría</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" action="<?= url('categoria', 'guardar') ?>" id="catForm">
                <input type="hidden" name="id" id="catId">
                <div class="modal-body p-4">
                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Nombre de la Categoría *</label>
                        <input type="text" name="nombre" id="catNombre" class="form-control" placeholder="Ej: Peluches Gigantes" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Descripción (Opcional)</label>
                        <textarea name="descripcion" id="catDescripcion" class="form-control" rows="3" placeholder="Detalles de los productos que pertenecen a esta categoría..."></textarea>
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-pink fw-semibold">Guardar</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    let catModal;
    function getCatModal() {
        if (!catModal) catModal = new bootstrap.Modal(document.getElementById('categoriaModal'));
        return catModal;
    }

    function abrirModalCategoria() {
        document.getElementById('catForm').reset();
        document.getElementById('catId').value = '';
        document.getElementById('catModalTitle').innerText = 'Nueva Categoría';
        getCatModal().show();
    }

    function editarCategoria(cat) {
        document.getElementById('catForm').reset();
        document.getElementById('catId').value = cat.id;
        document.getElementById('catNombre').value = cat.nombre;
        document.getElementById('catDescripcion').value = cat.descripcion || '';
        document.getElementById('catModalTitle').innerText = 'Editar Categoría';
        getCatModal().show();
    }
</script>

<?php require_once __DIR__ . '/../layouts/footer.php'; ?>
