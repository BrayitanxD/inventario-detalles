<?php
$pageTitle = 'Historial Kardex - Peluches & Detalles';
require_once __DIR__ . '/../layouts/header.php';
?>

<div class="d-flex flex-wrap justify-content-between align-items-center mb-4 gap-3">
    <div>
        <h3 class="fw-bold text-dark mb-1">Historial Kardex de Inventario</h3>
        <p class="text-muted small mb-0">Auditoría cronológica de cada entrada, venta y ajuste de existencias.</p>
    </div>
</div>

<!-- Filtros Kardex -->
<div class="card border-0 shadow-sm mb-4">
    <div class="card-body p-3">
        <form method="GET" action="<?= BASE_URL ?>/index.php" class="row g-2 align-items-center">
            <input type="hidden" name="c" value="movimiento">
            <input type="hidden" name="a" value="kardex">

            <div class="col-md-5">
                <select name="producto_id" class="form-select form-select-sm" onchange="this.form.submit()">
                    <option value="">Todos los Productos</option>
                    <?php foreach ($productos as $p): ?>
                        <option value="<?= $p['id'] ?>" <?= ($prodFiltro == $p['id']) ? 'selected' : '' ?>>
                            <?= htmlspecialchars($p['nombre']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="col-md-4">
                <select name="tipo" class="form-select form-select-sm" onchange="this.form.submit()">
                    <option value="">Todos los Tipos de Movimiento</option>
                    <option value="ENTRADA" <?= ($tipoFiltro === 'ENTRADA') ? 'selected' : '' ?>>Entradas (Compras y Ajustes)</option>
                    <option value="SALIDA_VENTA" <?= ($tipoFiltro === 'SALIDA_VENTA') ? 'selected' : '' ?>>Salidas por Venta POS</option>
                    <option value="SALIDA_MERMA" <?= ($tipoFiltro === 'SALIDA_MERMA') ? 'selected' : '' ?>>Salidas por Merma / Daño</option>
                    <option value="SALIDA_USO_INTERNO" <?= ($tipoFiltro === 'SALIDA_USO_INTERNO') ? 'selected' : '' ?>>Uso Interno</option>
                </select>
            </div>

            <div class="col-md-3 d-flex gap-2">
                <button type="submit" class="btn btn-dark btn-sm flex-grow-1">Filtrar</button>
                <?php if (!empty($tipoFiltro) || !empty($prodFiltro)): ?>
                    <a href="<?= url('movimiento', 'kardex') ?>" class="btn btn-outline-secondary btn-sm" title="Limpiar">
                        <i class="bi bi-x-circle"></i>
                    </a>
                <?php endif; ?>
            </div>
        </form>
    </div>
</div>

<!-- Tabla de Movimientos Kardex -->
<div class="card border-0 shadow-sm">
    <div class="table-responsive">
        <table class="table align-middle mb-0 table-hover">
            <thead class="table-light extra-small text-uppercase text-muted">
                <tr>
                    <th>Fecha & Hora</th>
                    <th>Producto</th>
                    <th>Tipo</th>
                    <th>Motivo / Referencia</th>
                    <th>Stock Ant.</th>
                    <th>Movimiento</th>
                    <th>Stock Resultante</th>
                    <th>Costo</th>
                    <th>Usuario</th>
                </tr>
            </thead>
            <tbody class="small">
                <?php if (empty($movimientos)): ?>
                    <tr>
                        <td colspan="9" class="text-center py-5 text-muted">
                            <i class="bi bi-clock-history fs-2 text-muted d-block mb-2"></i>
                            No se registran movimientos con los filtros seleccionados.
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($movimientos as $m): ?>
                        <?php 
                            $esEntrada = str_starts_with($m['tipo'], 'ENTRADA');
                            $tipoBadge = match($m['tipo']) {
                                'ENTRADA_COMPRA'     => 'bg-success text-white',
                                'ENTRADA_AJUSTE'     => 'bg-info text-white',
                                'SALIDA_VENTA'       => 'bg-primary text-white',
                                'SALIDA_MERMA'       => 'bg-danger text-white',
                                'SALIDA_USO_INTERNO' => 'bg-warning text-dark',
                                default              => 'bg-secondary text-white'
                            };
                        ?>
                        <tr>
                            <td class="text-muted extra-small"><?= date('d/m/Y H:i:s', strtotime($m['fecha'])) ?></td>
                            <td>
                                <div class="fw-bold text-dark"><?= htmlspecialchars($m['producto_nombre']) ?></div>
                                <span class="extra-small text-muted font-monospace"><?= htmlspecialchars($m['codigo_barras'] ?? '') ?></span>
                            </td>
                            <td>
                                <span class="badge <?= $tipoBadge ?> extra-small"><?= htmlspecialchars($m['tipo']) ?></span>
                            </td>
                            <td class="text-muted"><?= htmlspecialchars($m['motivo'] ?? 'N/A') ?></td>
                            <td class="text-center text-muted"><?= $m['stock_anterior'] ?></td>
                            <td class="text-center">
                                <?php if ($esEntrada): ?>
                                    <span class="text-success fw-bold">+<?= $m['cantidad'] ?></span>
                                <?php else: ?>
                                    <span class="text-danger fw-bold">-<?= $m['cantidad'] ?></span>
                                <?php endif; ?>
                            </td>
                            <td class="text-center fw-bold"><?= $m['stock_posterior'] ?></td>
                            <td class="text-muted"><?= formatPrice($m['costo_unitario']) ?></td>
                            <td class="text-muted extra-small"><?= htmlspecialchars($m['usuario_nombre']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once __DIR__ . '/../layouts/footer.php'; ?>
