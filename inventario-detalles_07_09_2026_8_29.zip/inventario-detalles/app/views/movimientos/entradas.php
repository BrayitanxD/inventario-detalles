<?php
$pageTitle = 'Entradas de Mercancía - Peluches & Detalles';
require_once __DIR__ . '/../layouts/header.php';
?>

<div class="d-flex flex-wrap justify-content-between align-items-center mb-4 gap-3">
    <div>
        <h3 class="fw-bold text-dark mb-1">Entradas de Mercancía</h3>
        <p class="text-muted small mb-0">Recepción de compras a proveedores y aumento directo de stock.</p>
    </div>
    <a href="<?= url('movimiento', 'kardex') ?>" class="btn btn-outline-secondary btn-sm">
        <i class="bi bi-clock-history me-1"></i> Ver Kardex Completo
    </a>
</div>

<div class="row g-4">
    <!-- Formulario de Registro de Entrada -->
    <div class="col-lg-5">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white py-3">
                <h6 class="fw-bold mb-0 text-success d-flex align-items-center gap-2">
                    <i class="bi bi-box-arrow-in-down fs-5"></i> Registrar Nueva Entrada
                </h6>
            </div>
            <form method="POST" action="<?= url('movimiento', 'guardarEntrada') ?>" class="p-4">
                <div class="mb-3">
                    <label class="form-label small fw-semibold">Seleccionar Producto *</label>
                    <select name="producto_id" id="entradaProductoSelect" class="form-select" required onchange="actualizarInfoProducto(this)">
                        <option value="">Seleccione un producto...</option>
                        <?php foreach ($productos as $p): ?>
                            <option value="<?= $p['id'] ?>" 
                                    data-costo="<?= $p['precio_compra'] ?>" 
                                    data-stock="<?= $p['stock_actual'] ?>">
                                <?= htmlspecialchars($p['nombre']) ?> (Stock actual: <?= $p['stock_actual'] ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="row g-2 mb-3">
                    <div class="col-6">
                        <label class="form-label small fw-semibold">Cantidad a Ingresar *</label>
                        <input type="number" name="cantidad" min="1" class="form-control" placeholder="Ej: 10" required>
                    </div>
                    <div class="col-6">
                        <label class="form-label small fw-semibold">Costo Unitario ($) *</label>
                        <input type="number" step="100" min="0" name="costo_unitario" id="entradaCostoUnitario" class="form-control" placeholder="0" required>
                    </div>
                </div>

                <div class="form-check mb-3">
                    <input class="form-check-input" type="checkbox" name="actualizar_costo" value="1" id="checkActualizarCosto" checked>
                    <label class="form-check-label small text-muted" for="checkActualizarCosto">
                        Actualizar costo de compra de este producto en el catálogo
                    </label>
                </div>

                <div class="mb-4">
                    <label class="form-label small fw-semibold">Proveedor / Factura / Observaciones</label>
                    <textarea name="motivo" class="form-control" rows="2" placeholder="Ej: Compra a Distribuidora de Peluches S.A.S - Factura #4589"></textarea>
                </div>

                <button type="submit" class="btn btn-success w-100 py-2 fw-semibold shadow-sm">
                    <i class="bi bi-check2-circle me-1"></i> Registrar Entrada de Stock
                </button>
            </form>
        </div>
    </div>

    <!-- Historial Reciente de Entradas -->
    <div class="col-lg-7">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-header bg-white py-3">
                <h6 class="fw-bold mb-0 text-dark">Últimas Entradas Registradas</h6>
            </div>
            <div class="table-responsive">
                <table class="table align-middle mb-0 table-hover">
                    <thead class="table-light extra-small text-uppercase text-muted">
                        <tr>
                            <th>Fecha</th>
                            <th>Producto</th>
                            <th>Cantidad</th>
                            <th>Costo Unit.</th>
                            <th>Stock Resultante</th>
                            <th>Usuario</th>
                        </tr>
                    </thead>
                    <tbody class="small">
                        <?php if (empty($historial)): ?>
                            <tr>
                                <td colspan="6" class="text-center py-4 text-muted">No se han registrado compras o entradas aún.</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($historial as $h): ?>
                                <tr>
                                    <td class="text-muted extra-small"><?= date('d/m/Y H:i', strtotime($h['fecha'])) ?></td>
                                    <td>
                                        <div class="fw-bold text-dark"><?= htmlspecialchars($h['producto_nombre']) ?></div>
                                        <div class="extra-small text-muted"><?= htmlspecialchars($h['motivo'] ?? '') ?></div>
                                    </td>
                                    <td>
                                        <span class="badge bg-success-subtle text-success fw-bold">+<?= $h['cantidad'] ?></span>
                                    </td>
                                    <td><?= formatPrice($h['costo_unitario']) ?></td>
                                    <td class="fw-semibold"><?= $h['stock_posterior'] ?> u.</td>
                                    <td class="text-muted extra-small"><?= htmlspecialchars($h['usuario_nombre']) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
    function actualizarInfoProducto(select) {
        const option = select.options[select.selectedIndex];
        const costo = option.getAttribute('data-costo') || '0';
        document.getElementById('entradaCostoUnitario').value = parseFloat(costo) || '';
    }
</script>

<?php require_once __DIR__ . '/../layouts/footer.php'; ?>
