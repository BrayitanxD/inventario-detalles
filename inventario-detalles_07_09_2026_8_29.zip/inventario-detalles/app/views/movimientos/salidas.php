<?php
$pageTitle = 'Salidas y Mermas - Peluches & Detalles';
require_once __DIR__ . '/../layouts/header.php';
?>

<div class="d-flex flex-wrap justify-content-between align-items-center mb-4 gap-3">
    <div>
        <h3 class="fw-bold text-dark mb-1">Salidas de Mercancía y Mermas</h3>
        <p class="text-muted small mb-0">Control de productos dañados, roturas, vencimientos o consumo para exhibición.</p>
    </div>
    <a href="<?= url('movimiento', 'kardex') ?>" class="btn btn-outline-secondary btn-sm">
        <i class="bi bi-clock-history me-1"></i> Ver Kardex Completo
    </a>
</div>

<div class="row g-4">
    <!-- Formulario Salida -->
    <div class="col-lg-5">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white py-3">
                <h6 class="fw-bold mb-0 text-danger d-flex align-items-center gap-2">
                    <i class="bi bi-box-arrow-up-right fs-5"></i> Registrar Salida / Ajuste Negativo
                </h6>
            </div>
            <form method="POST" action="<?= url('movimiento', 'guardarSalida') ?>" class="p-4" onsubmit="return validarStockSalida()">
                <div class="mb-3">
                    <label class="form-label small fw-semibold">Seleccionar Producto *</label>
                    <select name="producto_id" id="salidaProductoSelect" class="form-select" required onchange="actualizarStockSalida(this)">
                        <option value="">Seleccione un producto...</option>
                        <?php foreach ($productos as $p): ?>
                            <option value="<?= $p['id'] ?>" data-stock="<?= $p['stock_actual'] ?>">
                                <?= htmlspecialchars($p['nombre']) ?> (Disponible: <?= $p['stock_actual'] ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="row g-2 mb-3">
                    <div class="col-6">
                        <label class="form-label small fw-semibold">Cantidad a Retirar *</label>
                        <input type="number" name="cantidad" id="salidaCantidad" min="1" class="form-control" placeholder="1" required>
                    </div>
                    <div class="col-6">
                        <label class="form-label small fw-semibold">Tipo de Salida *</label>
                        <select name="tipo_salida" class="form-select" required>
                            <option value="SALIDA_MERMA">Merma / Daño</option>
                            <option value="SALIDA_USO_INTERNO">Uso Interno / Exhibición</option>
                        </select>
                    </div>
                </div>

                <div class="mb-4">
                    <label class="form-label small fw-semibold">Motivo Detallado *</label>
                    <textarea name="motivo" class="form-control" rows="3" placeholder="Ej: Globo metalizado vino pinchado de fábrica / Peluche con mancha en costura..." required></textarea>
                </div>

                <button type="submit" class="btn btn-danger w-100 py-2 fw-semibold shadow-sm">
                    <i class="bi bi-dash-circle me-1"></i> Descontar del Inventario
                </button>
            </form>
        </div>
    </div>

    <!-- Historial de Salidas no venta -->
    <div class="col-lg-7">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-header bg-white py-3">
                <h6 class="fw-bold mb-0 text-dark">Últimas Mermas y Ajustes Registrados</h6>
            </div>
            <div class="table-responsive">
                <table class="table align-middle mb-0 table-hover">
                    <thead class="table-light extra-small text-uppercase text-muted">
                        <tr>
                            <th>Fecha</th>
                            <th>Producto</th>
                            <th>Tipo</th>
                            <th>Cantidad</th>
                            <th>Stock Restante</th>
                            <th>Registrado Por</th>
                        </tr>
                    </thead>
                    <tbody class="small">
                        <?php if (empty($historial)): ?>
                            <tr>
                                <td colspan="6" class="text-center py-4 text-muted">No hay registro de mermas o pérdidas.</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($historial as $h): ?>
                                <tr>
                                    <td class="text-muted extra-small"><?= date('d/m/Y H:i', strtotime($h['fecha'])) ?></td>
                                    <td>
                                        <div class="fw-bold text-dark"><?= htmlspecialchars($h['producto_nombre']) ?></div>
                                        <div class="extra-small text-muted"><?= htmlspecialchars($h['motivo'] ?? '') ?></div>
                                    </td>
                                    <td>
                                        <span class="badge bg-danger-subtle text-danger"><?= htmlspecialchars($h['tipo']) ?></span>
                                    </td>
                                    <td>
                                        <span class="badge bg-danger fw-bold">-<?= $h['cantidad'] ?></span>
                                    </td>
                                    <td class="fw-semibold"><?= $h['stock_posterior'] ?> u.</td>
                                    <td class="text-muted extra-small"><?= htmlspecialchars($h['usuario_nombre']) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
    let stockMaximo = 0;

    function actualizarStockSalida(select) {
        const option = select.options[select.selectedIndex];
        stockMaximo = parseInt(option.getAttribute('data-stock') || '0');
        const inputCant = document.getElementById('salidaCantidad');
        inputCant.max = stockMaximo;
    }

    function validarStockSalida() {
        const cant = parseInt(document.getElementById('salidaCantidad').value || '0');
        if (cant > stockMaximo) {
            Swal.fire({
                icon: 'error',
                title: 'Stock Insuficiente',
                text: `No puedes retirar ${cant} unidades porque solo hay ${stockMaximo} disponibles.`
            });
            return false;
        }
        return true;
    }
</script>

<?php require_once __DIR__ . '/../layouts/footer.php'; ?>
