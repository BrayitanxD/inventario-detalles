<?php
$pageTitle = 'Dashboard - Peluches & Detalles';
require_once __DIR__ . '/../layouts/header.php';
?>

<!-- Encabezado de Bienvenida -->
<div class="d-flex flex-wrap justify-content-between align-items-center mb-4 gap-3">
    <div>
        <h3 class="fw-bold text-dark mb-1">¡Hola, <?= htmlspecialchars($usuario['nombre'] ?? 'Equipo') ?>! 👋</h3>
        <p class="text-muted small mb-0">Resumen operativo y estado general de tu tienda de detalles y peluches.</p>
    </div>
    <div class="d-flex align-items-center gap-2">
        <?php if ($cajaActiva): ?>
            <span class="badge bg-success-subtle text-success border border-success-subtle p-2 d-flex align-items-center gap-1">
                <i class="bi bi-unlock-fill"></i> Caja Abierta (Turno #<?= $cajaActiva['id'] ?>)
            </span>
            <a href="<?= url('caja', 'arqueo') ?>" class="btn btn-outline-secondary btn-sm">Ver Arqueo</a>
        <?php else: ?>
            <span class="badge bg-warning-subtle text-warning border border-warning-subtle p-2 d-flex align-items-center gap-1">
                <i class="bi bi-lock-fill"></i> Caja Cerrada
            </span>
            <a href="<?= url('caja', 'arqueo') ?>" class="btn btn-warning btn-sm fw-semibold">Abrir Caja</a>
        <?php endif; ?>
    </div>
</div>

<!-- Tarjetas de Métricas Principales -->
<div class="row g-3 mb-4">
    <!-- Ventas Hoy -->
    <div class="col-sm-6 col-xl-3">
        <div class="card metric-card border-0 shadow-sm p-3 h-100">
            <div class="d-flex justify-content-between align-items-center mb-2">
                <span class="text-muted small fw-semibold">Ventas de Hoy</span>
                <div class="metric-icon bg-primary-subtle text-primary">
                    <i class="bi bi-cash-coin"></i>
                </div>
            </div>
            <h4 class="fw-bold mb-1 text-dark"><?= formatPrice($metricas['ventas_hoy']) ?></h4>
            <div class="text-muted extra-small">
                <i class="bi bi-receipt me-1"></i> <?= $metricas['transacciones_hoy'] ?> transacciones registradas
            </div>
        </div>
    </div>

    <!-- Ventas Mes -->
    <div class="col-sm-6 col-xl-3">
        <div class="card metric-card border-0 shadow-sm p-3 h-100">
            <div class="d-flex justify-content-between align-items-center mb-2">
                <span class="text-muted small fw-semibold">Ventas del Mes</span>
                <div class="metric-icon bg-pink-light text-pink">
                    <i class="bi bi-calendar2-check"></i>
                </div>
            </div>
            <h4 class="fw-bold mb-1 text-dark"><?= formatPrice($metricas['ventas_mes']) ?></h4>
            <div class="text-muted extra-small">
                <i class="bi bi-bag-check me-1"></i> <?= $metricas['transacciones_mes'] ?> pedidos completados
            </div>
        </div>
    </div>

    <!-- Catálogo de Productos -->
    <div class="col-sm-6 col-xl-3">
        <div class="card metric-card border-0 shadow-sm p-3 h-100">
            <div class="d-flex justify-content-between align-items-center mb-2">
                <span class="text-muted small fw-semibold">Catálogo Total</span>
                <div class="metric-icon bg-success-subtle text-success">
                    <i class="bi bi-box-seam"></i>
                </div>
            </div>
            <h4 class="fw-bold mb-1 text-dark"><?= $metricas['total_productos'] ?> <span class="fs-6 fw-normal text-muted">items</span></h4>
            <div class="text-muted extra-small">
                <i class="bi bi-boxes me-1"></i> <?= $metricas['total_unidades'] ?> unidades físicas en stock
            </div>
        </div>
    </div>

    <!-- Alertas Stock Bajo -->
    <div class="col-sm-6 col-xl-3">
        <div class="card metric-card border-0 shadow-sm p-3 h-100">
            <div class="d-flex justify-content-between align-items-center mb-2">
                <span class="text-muted small fw-semibold">Bajo Stock</span>
                <div class="metric-icon bg-danger-subtle text-danger">
                    <i class="bi bi-exclamation-triangle-fill"></i>
                </div>
            </div>
            <h4 class="fw-bold mb-1 text-danger"><?= $metricas['productos_alerta'] ?> <span class="fs-6 fw-normal text-muted">por reponer</span></h4>
            <div class="extra-small">
                <a href="<?= url('movimiento', 'entradas') ?>" class="text-danger fw-semibold text-decoration-none">
                    Reabastecer ahora <i class="bi bi-arrow-right"></i>
                </a>
            </div>
        </div>
    </div>
</div>

<!-- Acciones Rápidas -->
<div class="card border-0 shadow-sm p-3 mb-4">
    <div class="d-flex flex-wrap gap-2 align-items-center">
        <span class="fw-bold small text-muted me-2">Accesos Rápidos:</span>
        <a href="<?= url('venta', 'pos') ?>" class="btn btn-pink btn-sm d-flex align-items-center gap-1 shadow-sm">
            <i class="bi bi-cart-plus-fill"></i> Nueva Venta (POS)
        </a>
        <a href="<?= url('movimiento', 'entradas') ?>" class="btn btn-outline-success btn-sm d-flex align-items-center gap-1">
            <i class="bi bi-box-arrow-in-down"></i> Entrada de Mercancía
        </a>
        <a href="<?= url('movimiento', 'salidas') ?>" class="btn btn-outline-danger btn-sm d-flex align-items-center gap-1">
            <i class="bi bi-box-arrow-up-right"></i> Registrar Merma / Daño
        </a>
        <a href="<?= url('producto', 'index') ?>" class="btn btn-outline-primary btn-sm d-flex align-items-center gap-1">
            <i class="bi bi-plus-circle"></i> Nuevo Producto
        </a>
        <a href="<?= url('caja', 'arqueo') ?>" class="btn btn-outline-dark btn-sm d-flex align-items-center gap-1">
            <i class="bi bi-cash-stack"></i> Arqueo de Turno
        </a>
    </div>
</div>

<div class="row g-4">
    <!-- Últimas Ventas -->
    <div class="col-lg-8">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
                <h6 class="fw-bold mb-0 text-dark d-flex align-items-center gap-2">
                    <i class="bi bi-clock-history text-primary"></i> Ventas Recientes
                </h6>
                <a href="<?= url('venta', 'historial') ?>" class="btn btn-sm btn-link text-decoration-none small">Ver todas</a>
            </div>
            <div class="table-responsive">
                <table class="table align-middle mb-0 table-hover">
                    <thead class="table-light extra-small text-uppercase text-muted">
                        <tr>
                            <th>Factura</th>
                            <th>Cliente</th>
                            <th>Método</th>
                            <th>Total</th>
                            <th>Fecha</th>
                            <th class="text-center">Ticket</th>
                        </tr>
                    </thead>
                    <tbody class="small">
                        <?php if (empty($ultimasVentas)): ?>
                            <tr>
                                <td colspan="6" class="text-center py-4 text-muted">
                                    No hay ventas registradas aún. ¡Realiza la primera desde el POS!
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($ultimasVentas as $v): ?>
                                <tr>
                                    <td class="fw-bold text-dark"><?= htmlspecialchars($v['numero_factura']) ?></td>
                                    <td><?= htmlspecialchars($v['cliente_nombre']) ?></td>
                                    <td>
                                        <span class="badge bg-light text-dark border"><?= htmlspecialchars($v['metodo_pago']) ?></span>
                                    </td>
                                    <td class="fw-bold text-primary"><?= formatPrice($v['total']) ?></td>
                                    <td class="text-muted extra-small"><?= date('d/m/Y H:i', strtotime($v['fecha'])) ?></td>
                                    <td class="text-center">
                                        <a href="<?= url('venta', 'factura', ['id' => $v['id']]) ?>" target="_blank" class="btn btn-outline-secondary btn-sm py-0 px-2" title="Imprimir Ticket">
                                            <i class="bi bi-printer"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Alertas de Stock y Top Productos -->
    <div class="col-lg-4">
        <!-- Stock Crítico -->
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
                <h6 class="fw-bold mb-0 text-danger d-flex align-items-center gap-2">
                    <i class="bi bi-exclamation-circle-fill"></i> Alertas de Stock Crítico
                </h6>
            </div>
            <div class="p-3">
                <?php if (empty($productosBajos)): ?>
                    <div class="text-center py-3 text-muted small">
                        <i class="bi bi-check-circle text-success fs-3 d-block mb-1"></i>
                        ¡Excelente! Todos los productos tienen stock adecuado.
                    </div>
                <?php else: ?>
                    <div class="list-group list-group-flush">
                        <?php foreach (array_slice($productosBajos, 0, 5) as $pb): ?>
                            <div class="list-group-item px-0 d-flex justify-content-between align-items-center">
                                <div class="overflow-hidden me-2">
                                    <div class="fw-semibold small text-truncate"><?= htmlspecialchars($pb['nombre']) ?></div>
                                    <span class="extra-small text-muted"><?= htmlspecialchars($pb['categoria_nombre']) ?></span>
                                </div>
                                <div class="text-end">
                                    <span class="badge bg-danger rounded-pill"><?= $pb['stock_actual'] ?> disp.</span>
                                    <div class="extra-small text-muted mt-1">Mín: <?= $pb['stock_minimo'] ?></div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <div class="mt-3 text-center">
                        <a href="<?= url('movimiento', 'entradas') ?>" class="btn btn-outline-danger btn-sm w-100">
                            <i class="bi bi-plus-lg me-1"></i> Reabastecer Stock
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Top Productos -->
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white py-3">
                <h6 class="fw-bold mb-0 text-dark d-flex align-items-center gap-2">
                    <i class="bi bi-star-fill text-warning"></i> Más Vendidos
                </h6>
            </div>
            <div class="p-3">
                <?php if (empty($topProductos)): ?>
                    <p class="text-muted small text-center mb-0 py-2">Aún no hay datos de ventas acumuladas.</p>
                <?php else: ?>
                    <ul class="list-unstyled mb-0">
                        <?php foreach ($topProductos as $idx => $tp): ?>
                            <li class="d-flex align-items-center justify-content-between mb-2 pb-2 border-bottom">
                                <div class="d-flex align-items-center gap-2">
                                    <span class="badge bg-light text-muted border"><?= $idx + 1 ?></span>
                                    <span class="small fw-semibold text-truncate" style="max-width: 170px;"><?= htmlspecialchars($tp['nombre']) ?></span>
                                </div>
                                <span class="badge bg-primary-subtle text-primary fw-bold"><?= $tp['total_vendido'] ?> u.</span>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../layouts/footer.php'; ?>
