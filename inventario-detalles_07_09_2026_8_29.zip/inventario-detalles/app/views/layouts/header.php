<?php
// Layout Header
$usuario = currentUser();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($pageTitle ?? APP_NAME) ?></title>
    
    <!-- Google Fonts: Poppins & Inter -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- Bootstrap 5.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <!-- SweetAlert2 -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    
    <!-- Estilos Personalizados -->
    <link rel="stylesheet" href="<?= asset('css/custom.css') ?>">
</head>
<body class="bg-light">

<!-- Navbar Superior -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark-navy sticky-top shadow-sm">
    <div class="container-fluid px-3">
        <button class="btn btn-outline-light btn-sm me-2 d-lg-none" type="button" data-bs-toggle="offcanvas" data-bs-target="#sidebarMenu">
            <i class="bi bi-list fs-5"></i>
        </button>
        <a class="navbar-brand d-flex align-items-center gap-2 fw-bold text-white" href="<?= url('dashboard', 'index') ?>">
            <span class="brand-icon"><i class="bi bi-gift-fill text-pink"></i></span>
            <span>Peluches & Detalles</span>
        </a>

        <div class="d-flex align-items-center gap-3 ms-auto">
            <!-- Acceso rápido POS -->
            <a href="<?= url('venta', 'pos') ?>" class="btn btn-pink btn-sm d-flex align-items-center gap-1 fw-semibold shadow-sm">
                <i class="bi bi-cart-check-fill"></i>
                <span class="d-none d-sm-inline">Punto de Venta</span>
            </a>

            <!-- Acceso rápido Arqueo -->
            <a href="<?= url('caja', 'arqueo') ?>" class="btn btn-outline-light btn-sm d-flex align-items-center gap-1">
                <i class="bi bi-cash-stack"></i>
                <span class="d-none d-md-inline">Caja</span>
            </a>

            <!-- Perfil / Usuario Dropdown -->
            <div class="dropdown">
                <button class="btn btn-user-badge dropdown-toggle d-flex align-items-center gap-2 py-1 px-2" type="button" data-bs-target="#userMenu" data-bs-toggle="dropdown">
                    <div class="avatar-circle">
                        <?= strtoupper(substr($usuario['nombre'] ?? 'U', 0, 1)) ?>
                    </div>
                    <span class="d-none d-md-inline text-white small fw-medium"><?= htmlspecialchars($usuario['nombre'] ?? 'Usuario') ?></span>
                    <span class="badge bg-secondary small"><?= strtoupper($usuario['rol'] ?? '') ?></span>
                </button>
                <ul class="dropdown-menu dropdown-menu-end shadow-sm" id="userMenu">
                    <li><h6 class="dropdown-header">Conectado como <?= htmlspecialchars($usuario['usuario'] ?? '') ?></h6></li>
                    <li><hr class="dropdown-divider"></li>
                    <li>
                        <a class="dropdown-item text-danger d-flex align-items-center gap-2" href="<?= url('auth', 'logout') ?>">
                            <i class="bi bi-box-arrow-right"></i> Cerrar Sesión
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</nav>

<div class="container-fluid">
    <div class="row">
        <!-- Sidebar Navigation -->
        <?php require_once __DIR__ . '/sidebar.php'; ?>

        <!-- Contenido Principal -->
        <main class="col-lg-10 ms-sm-auto px-md-4 py-4 main-content">
