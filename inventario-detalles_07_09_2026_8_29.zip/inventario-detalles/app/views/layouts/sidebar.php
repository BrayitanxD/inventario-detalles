<?php
// Layout Sidebar
$currentController = $_GET['c'] ?? 'dashboard';
$currentAction     = $_GET['a'] ?? 'index';

function isActive(string $controller, ?string $action = null): string {
    global $currentController, $currentAction;
    if ($currentController === $controller) {
        if ($action === null || $currentAction === $action) {
            return 'active';
        }
    }
    return '';
}
?>

<!-- Sidebar para pantallas grandes y Offcanvas para móviles -->
<div class="col-lg-2 p-0 bg-white border-end sidebar-wrapper">
    <div class="offcanvas-lg offcanvas-start p-3 bg-white" tabindex="-1" id="sidebarMenu">
        <div class="offcanvas-header d-lg-none border-bottom pb-2 mb-3">
            <h5 class="offcanvas-title fw-bold text-primary">Menú Principal</h5>
            <button type="button" class="btn-close" data-bs-dismiss="offcanvas" data-bs-target="#sidebarMenu"></button>
        </div>

        <div class="sidebar-sticky">
            <div class="text-uppercase text-muted fw-bold extra-small mb-2 px-3">Operaciones Diarias</div>
            <ul class="nav flex-column mb-3">
                <li class="nav-item">
                    <a class="nav-link <?= isActive('dashboard') ?>" href="<?= url('dashboard', 'index') ?>">
                        <i class="bi bi-grid-1x2-fill me-2"></i> Dashboard
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-pink fw-semibold <?= isActive('venta', 'pos') ?>" href="<?= url('venta', 'pos') ?>">
                        <i class="bi bi-cart-check-fill me-2"></i> Punto de Venta (POS)
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= isActive('caja', 'arqueo') ?>" href="<?= url('caja', 'arqueo') ?>">
                        <i class="bi bi-cash-stack me-2"></i> Arqueo de Caja
                    </a>
                </li>
            </ul>

            <div class="text-uppercase text-muted fw-bold extra-small mb-2 px-3">Inventario & Catálogo</div>
            <ul class="nav flex-column mb-3">
                <li class="nav-item">
                    <a class="nav-link <?= isActive('producto', 'index') ?>" href="<?= url('producto', 'index') ?>">
                        <i class="bi bi-box-seam me-2"></i> Productos
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= isActive('categoria', 'index') ?>" href="<?= url('categoria', 'index') ?>">
                        <i class="bi bi-tags me-2"></i> Categorías
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-success <?= isActive('movimiento', 'entradas') ?>" href="<?= url('movimiento', 'entradas') ?>">
                        <i class="bi bi-box-arrow-in-down me-2"></i> Entradas / Compras
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-danger <?= isActive('movimiento', 'salidas') ?>" href="<?= url('movimiento', 'salidas') ?>">
                        <i class="bi bi-box-arrow-up-right me-2"></i> Salidas / Mermas
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= isActive('movimiento', 'kardex') ?>" href="<?= url('movimiento', 'kardex') ?>">
                        <i class="bi bi-clock-history me-2"></i> Historial Kardex
                    </a>
                </li>
            </ul>

            <div class="text-uppercase text-muted fw-bold extra-small mb-2 px-3">Ventas & Reportes</div>
            <ul class="nav flex-column mb-4">
                <li class="nav-item">
                    <a class="nav-link <?= isActive('venta', 'historial') ?>" href="<?= url('venta', 'historial') ?>">
                        <i class="bi bi-receipt me-2"></i> Facturas Emitidas
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= isActive('reporte', 'index') ?>" href="<?= url('reporte', 'index') ?>">
                        <i class="bi bi-graph-up-arrow me-2"></i> Informes & Ganancias
                    </a>
                </li>
            </ul>

            <div class="card bg-pink-light border-0 p-3 rounded-4 mt-auto">
                <div class="d-flex align-items-center gap-2 mb-2">
                    <i class="bi bi-balloon-heart-fill text-pink fs-4"></i>
                    <span class="fw-bold small text-dark">Tip para tienda</span>
                </div>
                <p class="extra-small text-muted mb-0">
                    Mantén actualizado el stock mínimo de globos y peluches para nunca quedarte sin insumos en fechas clave.
                </p>
            </div>
        </div>
    </div>
</div>
