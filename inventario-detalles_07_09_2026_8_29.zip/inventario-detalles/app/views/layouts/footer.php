        </main>
    </div>
</div>

<!-- Bootstrap 5.3 JS Bundle -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<!-- SweetAlert2 JS -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<!-- App Global JS -->
<script src="<?= asset('js/app.js') ?>"></script>

<!-- Notificaciones Flash -->
<script>
    <?php if ($msg = getFlash('success')): ?>
        Swal.fire({
            icon: 'success',
            title: '¡Operación Exitosa!',
            text: '<?= addslashes($msg) ?>',
            timer: 3000,
            showConfirmButton: false,
            toast: true,
            position: 'top-end'
        });
    <?php endif; ?>

    <?php if ($msg = getFlash('error')): ?>
        Swal.fire({
            icon: 'error',
            title: 'Atención',
            text: '<?= addslashes($msg) ?>',
            confirmButtonColor: '#d33'
        });
    <?php endif; ?>

    <?php if ($msg = getFlash('info')): ?>
        Swal.fire({
            icon: 'info',
            title: 'Información',
            text: '<?= addslashes($msg) ?>',
            timer: 3000,
            showConfirmButton: false,
            toast: true,
            position: 'top-end'
        });
    <?php endif; ?>
</script>

<?php if (!empty($extraScripts)): ?>
    <?php foreach ($extraScripts as $script): ?>
        <script src="<?= asset($script) ?>"></script>
    <?php endforeach; ?>
<?php endif; ?>

</body>
</html>
