<?php
$pageTitle = 'Historial de Facturas - Peluches & Detalles';
require_once __DIR__ . '/../layouts/header.php';
?>

<div class="d-flex flex-wrap justify-content-between align-items-center mb-4 gap-3">
    <div>
        <h3 class="fw-bold text-dark mb-1">Historial de Ventas y Facturas</h3>
        <p class="text-muted small mb-0">Consulta, reimpresión y gestión de comprobantes emitidos.</p>
    </div>
    <a href="<?= url('venta', 'pos') ?>" class="btn btn-pink btn-sm d-flex align-items-center gap-1 fw-semibold shadow-sm">
        <i class="bi bi-cart-plus-fill"></i> Nueva Venta (POS)
    </a>
</div>

<!-- Filtros de Facturas -->
<div class="card border-0 shadow-sm mb-4">
    <div class="card-body p-3">
        <form method="GET" action="<?= BASE_URL ?>/index.php" class="row g-2 align-items-center">
            <input type="hidden" name="c" value="venta">
            <input type="hidden" name="a" value="historial">

            <div class="col-md-3">
                <input type="text" name="q" class="form-control form-control-sm" placeholder="Buscar por # factura, cliente..." value="<?= htmlspecialchars($filtros['busqueda'] ?? '') ?>">
            </div>

            <div class="col-md-3">
                <select name="metodo_pago" class="form-select form-select-sm">
                    <option value="">Todos los Métodos de Pago</option>
                    <option value="EFECTIVO" <?= ($filtros['metodo_pago'] === 'EFECTIVO') ? 'selected' : '' ?>>Efectivo</option>
                    <option value="NEQUI" <?= ($filtros['metodo_pago'] === 'NEQUI') ? 'selected' : '' ?>>Nequi</option>
                    <option value="DAVIPLATA" <?= ($filtros['metodo_pago'] === 'DAVIPLATA') ? 'selected' : '' ?>>Daviplata</option>
                    <option value="TARJETA" <?= ($filtros['metodo_pago'] === 'TARJETA') ? 'selected' : '' ?>>Tarjeta</option>
                    <option value="TRANSFERENCIA" <?= ($filtros['metodo_pago'] === 'TRANSFERENCIA') ? 'selected' : '' ?>>Transferencia</option>
                </select>
            </div>

            <div class="col-md-2">
                <input type="date" name="fecha_inicio" class="form-control form-control-sm" value="<?= htmlspecialchars($filtros['fecha_inicio'] ?? '') ?>">
            </div>

            <div class="col-md-2">
                <input type="date" name="fecha_fin" class="form-control form-control-sm" value="<?= htmlspecialchars($filtros['fecha_fin'] ?? '') ?>">
            </div>

            <div class="col-md-2 d-flex gap-2">
                <button type="submit" class="btn btn-dark btn-sm flex-grow-1">Filtrar</button>
                <a href="<?= url('venta', 'historial') ?>" class="btn btn-outline-secondary btn-sm" title="Limpiar"><i class="bi bi-x-circle"></i></a>
            </div>
        </form>
    </div>
</div>

<!-- Listado de Facturas -->
<div class="card border-0 shadow-sm">
    <div class="table-responsive">
        <table class="table align-middle mb-0 table-hover">
            <thead class="table-light extra-small text-uppercase text-muted">
                <tr>
                    <th>Factura</th>
                    <th>Cliente</th>
                    <th>Fecha & Hora</th>
                    <th>Método de Pago</th>
                    <th>Total</th>
                    <th>Atendido Por</th>
                    <th>Estado</th>
                    <th class="text-end pe-3">Acciones</th>
                </tr>
            </thead>
            <tbody class="small">
                <?php if (empty($ventas)): ?>
                    <tr>
                        <td colspan="8" class="text-center py-5 text-muted">
                            <i class="bi bi-receipt-cutoff fs-1 d-block mb-2 text-muted"></i>
                            No se encontraron facturas registradas.
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($ventas as $v): ?>
                        <?php 
                            $esAnulada = $v['estado'] === 'ANULADA';
                        ?>
                        <tr class="<?= $esAnulada ? 'table-secondary opacity-75' : '' ?>">
                            <td class="fw-bold font-monospace text-dark"><?= htmlspecialchars($v['numero_factura']) ?></td>
                            <td>
                                <div><?= htmlspecialchars($v['cliente_nombre']) ?></div>
                                <?php if (!empty($v['cliente_documento'])): ?>
                                    <span class="extra-small text-muted"><?= htmlspecialchars($v['cliente_documento']) ?></span>
                                <?php endif; ?>
                            </td>
                            <td class="text-muted extra-small"><?= date('d/m/Y H:i', strtotime($v['fecha'])) ?></td>
                            <td>
                                <span class="badge bg-light text-dark border"><?= htmlspecialchars($v['metodo_pago']) ?></span>
                            </td>
                            <td class="fw-bold text-primary"><?= formatPrice($v['total']) ?></td>
                            <td class="text-muted extra-small"><?= htmlspecialchars($v['usuario_nombre']) ?></td>
                            <td>
                                <?php if ($esAnulada): ?>
                                    <span class="badge bg-danger-subtle text-danger">ANULADA</span>
                                <?php else: ?>
                                    <span class="badge bg-success-subtle text-success">COMPLETADA</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-end pe-3">
                                <a href="<?= url('venta', 'factura', ['id' => $v['id']]) ?>" target="_blank" class="btn btn-outline-primary btn-sm py-1 px-2 me-1" title="Ver / Imprimir Ticket">
                                    <i class="bi bi-printer"></i>
                                </a>
                                <?php if (!$esAnulada && ($_SESSION['user']['rol'] ?? '') === 'admin'): ?>
                                    <form method="POST" action="<?= url('venta', 'anular') ?>" class="d-inline" onsubmit="confirmarAccion(event, '¿Anular Factura?', 'El monto se cancelará y todos los productos regresarán al inventario.')">
                                        <input type="hidden" name="id" value="<?= $v['id'] ?>">
                                        <button type="submit" class="btn btn-outline-danger btn-sm py-1 px-2" title="Anular Factura">
                                            <i class="bi bi-x-circle"></i>
                                        </button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once __DIR__ . '/../layouts/footer.php'; ?>
