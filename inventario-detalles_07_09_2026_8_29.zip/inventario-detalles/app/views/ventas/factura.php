<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Factura <?= htmlspecialchars($venta['numero_factura']) ?> - Peluches & Detalles</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="<?= asset('css/custom.css') ?>">
    <style>
        body {
            background-color: #f1f5f9;
        }
        .ticket-box {
            max-width: 360px;
            margin: 20px auto;
            background: #ffffff;
            padding: 20px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.06);
            border-radius: 8px;
            font-family: 'Courier New', Courier, monospace;
            font-size: 13px;
            color: #000;
        }
        .line-dashed {
            border-top: 1px dashed #000;
            margin: 10px 0;
        }
        .line-double {
            border-top: 2px solid #000;
            margin: 10px 0;
        }
        @media print {
            body {
                background: #fff;
            }
            .no-print {
                display: none !important;
            }
            .ticket-box {
                box-shadow: none;
                margin: 0;
                padding: 5px;
                max-width: 100%;
                width: 80mm;
            }
        }
    </style>
</head>
<body>

<!-- Botones de Acción (no se imprimen) -->
<div class="container text-center my-3 no-print">
    <button class="btn btn-primary btn-sm me-2 shadow-sm" onclick="window.print()">
        <i class="bi bi-printer me-1"></i> Imprimir Factura / Ticket
    </button>
    <a href="<?= url('venta', 'pos') ?>" class="btn btn-outline-secondary btn-sm">
        <i class="bi bi-arrow-left me-1"></i> Volver al POS
    </a>
</div>

<!-- Ticket Térmico -->
<div class="ticket-box">
    <div class="text-center">
        <h5 class="fw-bold mb-1"><?= BUSINESS_NAME ?></h5>
        <div class="small">NIT: <?= BUSINESS_NIT ?></div>
        <div class="small"><?= BUSINESS_ADDRESS ?></div>
        <div class="small">Tel: <?= BUSINESS_PHONE ?></div>
        <div class="line-dashed"></div>
        <div class="fw-bold fs-6">FACTURA DE VENTA</div>
        <div class="fw-bold"><?= htmlspecialchars($venta['numero_factura']) ?></div>
        <div class="small">Fecha: <?= date('d/m/Y H:i:s', strtotime($venta['fecha'])) ?></div>
        <div class="small">Atendido por: <?= htmlspecialchars($venta['usuario_nombre']) ?></div>
    </div>

    <div class="line-dashed"></div>

    <div>
        <div><strong>Cliente:</strong> <?= htmlspecialchars($venta['cliente_nombre']) ?></div>
        <?php if (!empty($venta['cliente_documento'])): ?>
            <div><strong>Cédula/NIT:</strong> <?= htmlspecialchars($venta['cliente_documento']) ?></div>
        <?php endif; ?>
        <?php if (!empty($venta['cliente_telefono'])): ?>
            <div><strong>Teléfono:</strong> <?= htmlspecialchars($venta['cliente_telefono']) ?></div>
        <?php endif; ?>
    </div>

    <div class="line-dashed"></div>

    <table class="w-100" style="font-size: 12px;">
        <thead>
            <tr>
                <th class="text-start">DESCRIPCIÓN</th>
                <th class="text-center">CANT</th>
                <th class="text-end">TOTAL</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($detalles as $det): ?>
                <tr>
                    <td class="text-start py-1">
                        <?= htmlspecialchars($det['producto_nombre']) ?>
                        <div class="text-muted extra-small" style="font-size: 10px;">@ <?= formatPrice($det['precio_unitario']) ?></div>
                    </td>
                    <td class="text-center align-top"><?= $det['cantidad'] ?></td>
                    <td class="text-end align-top"><?= formatPrice($det['subtotal']) ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <div class="line-dashed"></div>

    <table class="w-100" style="font-size: 13px;">
        <tr>
            <td>SUBTOTAL:</td>
            <td class="text-end"><?= formatPrice($venta['subtotal']) ?></td>
        </tr>
        <?php if ($venta['descuento'] > 0): ?>
            <tr>
                <td>DESCUENTO:</td>
                <td class="text-end">-<?= formatPrice($venta['descuento']) ?></td>
            </tr>
        <?php endif; ?>
        <tr class="fw-bold fs-6">
            <td>TOTAL A PAGAR:</td>
            <td class="text-end"><?= formatPrice($venta['total']) ?></td>
        </tr>
    </table>

    <div class="line-dashed"></div>

    <table class="w-100" style="font-size: 12px;">
        <tr>
            <td>MÉTODO DE PAGO:</td>
            <td class="text-end fw-bold"><?= htmlspecialchars($venta['metodo_pago']) ?></td>
        </tr>
        <?php if ($venta['metodo_pago'] === 'EFECTIVO'): ?>
            <tr>
                <td>EFECTIVO RECIBIDO:</td>
                <td class="text-end"><?= formatPrice($venta['monto_recibido']) ?></td>
            </tr>
            <tr class="fw-bold">
                <td>CAMBIO / VUELTAS:</td>
                <td class="text-end"><?= formatPrice($venta['cambio']) ?></td>
            </tr>
        <?php endif; ?>
    </table>

    <div class="line-double"></div>

    <div class="text-center mt-3" style="font-size: 11px;">
        <p class="mb-1 fw-bold">¡Gracias por tu compra!</p>
        <p class="mb-1">Peluches gigantes, anchetas sorpresa y decoraciones mágicas para cada ocasión especial.</p>
        <p class="text-muted mb-0">Sistema de Control v1.0</p>
    </div>
</div>

</body>
</html>
