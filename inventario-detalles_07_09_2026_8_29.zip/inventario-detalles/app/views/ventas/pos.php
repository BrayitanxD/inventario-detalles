<?php
$pageTitle = 'Punto de Venta (POS) - Peluches & Detalles';
$extraScripts = ['js/pos.js'];
require_once __DIR__ . '/../layouts/header.php';
?>

<?php if (!$cajaActiva): ?>
    <div class="alert alert-warning d-flex align-items-center justify-content-between mb-3 shadow-sm rounded-4" role="alert">
        <div class="d-flex align-items-center gap-2">
            <i class="bi bi-exclamation-triangle-fill fs-4 text-warning"></i>
            <div>
                <strong>¡Atención! La caja se encuentra cerrada.</strong>
                <div class="small">Es recomendable abrir turno para registrar las ventas en efectivo y poder realizar el arqueo.</div>
            </div>
        </div>
        <a href="<?= url('caja', 'arqueo') ?>" class="btn btn-warning btn-sm fw-bold">
            <i class="bi bi-cash-stack me-1"></i> Abrir Caja Ahora
        </a>
    </div>
<?php endif; ?>

<div class="row g-3">
    <!-- Catálogo de Productos y Búsqueda -->
    <div class="col-lg-7 col-xl-8">
        <div class="card border-0 shadow-sm p-3 mb-3 bg-white">
            <div class="row g-2">
                <!-- Lector Código de Barras -->
                <div class="col-md-5">
                    <div class="input-group">
                        <span class="input-group-text bg-light text-muted"><i class="bi bi-upc-scan"></i></span>
                        <input type="text" id="posBarcodeInput" class="form-control" placeholder="Escanear código de barras..." autofocus>
                    </div>
                </div>
                <!-- Búsqueda en Vivo por Nombre -->
                <div class="col-md-7">
                    <div class="input-group">
                        <span class="input-group-text bg-light text-muted"><i class="bi bi-search"></i></span>
                        <input type="text" id="posSearchInput" class="form-control" placeholder="Buscar por nombre (ej: oso, stitch, ferrero)...">
                    </div>
                </div>
            </div>

            <!-- Filtro de Categorías rápido -->
            <div class="d-flex gap-2 overflow-auto pt-3 pb-1">
                <button type="button" class="btn btn-sm btn-outline-dark active rounded-pill px-3 text-nowrap" onclick="fetchProducts('')">
                    Todos
                </button>
                <?php foreach ($categorias as $cat): ?>
                    <button type="button" class="btn btn-sm btn-outline-secondary rounded-pill px-3 text-nowrap" onclick="fetchProducts('<?= htmlspecialchars($cat['nombre']) ?>')">
                        <?= htmlspecialchars($cat['nombre']) ?>
                    </button>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- Grid de Productos -->
        <div class="row g-3" id="posProductsGrid" style="max-height: calc(100vh - 270px); overflow-y: auto;">
            <?php foreach ($productosDestacados as $p): ?>
                <?php 
                    $stockCritico = $p['stock_actual'] <= $p['stock_minimo'];
                    $stockBadgeClass = $stockCritico ? 'badge bg-danger' : 'badge bg-success';
                    $imgUrl = !empty($p['imagen']) ? asset($p['imagen']) : 'https://placehold.co/200x150/fdf2f8/ec4899?text=Detalle';
                ?>
                <div class="col-6 col-md-4 col-xl-3 mb-2">
                    <div class="card h-100 pos-product-card shadow-sm" onclick='addToCart(<?= json_encode($p) ?>)'>
                        <img src="<?= $imgUrl ?>" class="card-img-top pos-product-img" alt="<?= htmlspecialchars($p['nombre']) ?>">
                        <div class="card-body p-2 d-flex flex-column">
                            <span class="badge bg-light text-secondary extra-small text-truncate mb-1"><?= htmlspecialchars($p['categoria_nombre'] ?? 'General') ?></span>
                            <h6 class="card-title fs-6 fw-bold mb-1 text-truncate" title="<?= htmlspecialchars($p['nombre']) ?>"><?= htmlspecialchars($p['nombre']) ?></h6>
                            <div class="mt-auto d-flex justify-content-between align-items-center pt-2">
                                <span class="text-primary fw-bold"><?= formatPrice($p['precio_venta']) ?></span>
                                <span class="<?= $stockBadgeClass ?> extra-small">Stock: <?= $p['stock_actual'] ?></span>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- Panel del Carrito y Pago POS -->
    <div class="col-lg-5 col-xl-4">
        <div class="card border-0 shadow-sm pos-cart-panel p-3">
            <div class="d-flex justify-content-between align-items-center border-bottom pb-2 mb-2">
                <div class="d-flex align-items-center gap-2">
                    <h6 class="fw-bold text-dark mb-0"><i class="bi bi-cart3 text-pink me-1"></i> Carrito</h6>
                    <span class="badge bg-pink rounded-pill" id="cartTotalItemsBadge">0</span>
                </div>
                <button type="button" class="btn btn-link text-danger p-0 extra-small text-decoration-none" onclick="clearCart()">
                    <i class="bi bi-trash"></i> Vaciar
                </button>
            </div>

            <!-- Lista de Items en el Carrito -->
            <div class="pos-cart-items" id="posCartItemsContainer">
                <!-- Inyectado dinámicamente por pos.js -->
            </div>

            <!-- Datos del Cliente (Acordeón colapsable para rapidez) -->
            <div class="accordion my-2" id="accordionCliente">
                <div class="accordion-item border-0 bg-light rounded-3">
                    <h2 class="accordion-header">
                        <button class="accordion-button collapsed py-2 px-3 extra-small fw-semibold text-muted bg-transparent shadow-none" type="button" data-bs-toggle="collapse" data-bs-target="#collapseCliente">
                            <i class="bi bi-person me-1"></i> Datos del Cliente (Opcional)
                        </button>
                    </h2>
                    <div id="collapseCliente" class="accordion-collapse collapse" data-bs-parent="#accordionCliente">
                        <div class="accordion-body p-2 pt-0">
                            <input type="text" id="posClienteNombre" class="form-control form-control-sm mb-1" placeholder="Nombre completo" value="Consumidor Final">
                            <div class="row g-1">
                                <div class="col-6">
                                    <input type="text" id="posClienteDoc" class="form-control form-control-sm" placeholder="Cédula / NIT">
                                </div>
                                <div class="col-6">
                                    <input type="text" id="posClienteTel" class="form-control form-control-sm" placeholder="Teléfono">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Totales y Métodos de Pago -->
            <div class="border-top pt-2">
                <div class="d-flex justify-content-between text-muted small mb-1">
                    <span>Subtotal:</span>
                    <span id="posSubtotalText" class="fw-semibold">$ 0</span>
                </div>
                <div class="d-flex justify-content-between align-items-center text-muted small mb-1">
                    <span>Descuento ($):</span>
                    <input type="number" id="posDiscountInput" class="form-control form-control-sm text-end py-0 px-2" style="width: 90px;" min="0" value="0">
                </div>
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <span class="fs-5 fw-bold text-dark">Total a Pagar:</span>
                    <span id="posTotalText" class="fs-4 fw-bold text-primary">$ 0</span>
                </div>

                <div class="mb-2">
                    <label class="form-label extra-small fw-semibold text-muted mb-1">Método de Pago</label>
                    <select id="posPaymentMethod" class="form-select form-select-sm">
                        <option value="EFECTIVO">Efectivo 💵</option>
                        <option value="NEQUI">Nequi 📱</option>
                        <option value="DAVIPLATA">Daviplata 📱</option>
                        <option value="TARJETA">Tarjeta Débito / Crédito 💳</option>
                        <option value="TRANSFERENCIA">Transferencia Bancaria 🏦</option>
                    </select>
                </div>

                <!-- Cálculo de cambio (solo efectivo) -->
                <div id="cashCalculationContainer" class="p-2 bg-light rounded-3 mb-2">
                    <div class="row g-2 align-items-center">
                        <div class="col-6">
                            <label class="extra-small fw-semibold text-muted mb-0">Efectivo Recibido:</label>
                            <input type="number" id="posAmountReceived" class="form-control form-control-sm text-end fw-bold" placeholder="0">
                        </div>
                        <div class="col-6 text-end">
                            <span class="extra-small text-muted d-block">Cambio / Vueltas:</span>
                            <span id="posChangeText" class="fw-bold text-success fs-6">$ 0</span>
                        </div>
                    </div>
                </div>

                <!-- Botón de Cobro Final -->
                <button type="button" id="btnCompletarVenta" class="btn btn-pink w-100 py-2 fw-bold fs-6 shadow-sm" onclick="submitSale()" disabled>
                    <i class="bi bi-check2-circle me-1"></i> Finalizar Venta
                </button>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../layouts/footer.php'; ?>
