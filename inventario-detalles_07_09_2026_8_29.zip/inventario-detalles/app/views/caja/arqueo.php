<?php
$pageTitle = 'Arqueo de Caja - Peluches & Detalles';
require_once __DIR__ . '/../layouts/header.php';
?>

<div class="d-flex flex-wrap justify-content-between align-items-center mb-4 gap-3">
    <div>
        <h3 class="fw-bold text-dark mb-1">Arqueo y Control de Caja</h3>
        <p class="text-muted small mb-0">Gestión de turnos, apertura con base, gastos menores y cuadre de efectivo.</p>
    </div>
</div>

<?php if (!$cajaActiva): ?>
    <!-- Pantalla de Apertura de Caja -->
    <div class="row justify-content-center my-4">
        <div class="col-md-6 col-lg-5">
            <div class="card border-0 shadow-sm p-4 text-center">
                <div class="p-3 bg-light rounded-circle d-inline-block mx-auto mb-3">
                    <i class="bi bi-cash-stack text-warning fs-1"></i>
                </div>
                <h4 class="fw-bold text-dark mb-1">No hay Caja Abierta</h4>
                <p class="text-muted small mb-4">Ingresa el monto de dinero base con el que iniciarás el turno para dar cambio.</p>

                <form method="POST" action="<?= url('caja', 'abrir') ?>">
                    <div class="mb-4 text-start">
                        <label class="form-label small fw-semibold">Base de Apertura ($)</label>
                        <div class="input-group input-group-lg">
                            <span class="input-group-text bg-light">$</span>
                            <input type="number" step="1000" min="0" name="monto_apertura" class="form-control fw-bold" placeholder="50000" value="50000" required>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-warning w-100 py-2 fw-bold text-dark shadow-sm">
                        <i class="bi bi-unlock-fill me-1"></i> Abrir Turno de Caja
                    </button>
                </form>
            </div>
        </div>
    </div>
<?php else: ?>
    <!-- Caja Activa: Indicadores de Turno -->
    <div class="card border-0 shadow-sm p-3 mb-4 bg-white">
        <div class="d-flex flex-wrap justify-content-between align-items-center gap-3">
            <div class="d-flex align-items-center gap-3">
                <div class="p-3 bg-success-subtle text-success rounded-4">
                    <i class="bi bi-unlock-fill fs-3"></i>
                </div>
                <div>
                    <span class="badge bg-success mb-1">Caja en Operación</span>
                    <h5 class="fw-bold text-dark mb-0">Turno #<?= $cajaActiva['id'] ?> - <?= htmlspecialchars($cajaActiva['usuario_nombre']) ?></h5>
                    <small class="text-muted">Apertura: <?= date('d/m/Y H:i', strtotime($cajaActiva['fecha_apertura'])) ?></small>
                </div>
            </div>

            <div class="d-flex gap-2">
                <button type="button" class="btn btn-outline-danger btn-sm d-flex align-items-center gap-1" data-bs-toggle="modal" data-bs-target="#modalGasto">
                    <i class="bi bi-dash-circle"></i> Registrar Gasto Menor
                </button>
                <button type="button" class="btn btn-outline-success btn-sm d-flex align-items-center gap-1" data-bs-toggle="modal" data-bs-target="#modalIngreso">
                    <i class="bi bi-plus-circle"></i> Ingreso de Efectivo
                </button>
            </div>
        </div>
    </div>

    <!-- Tarjetas de Balance de Arqueo -->
    <div class="row g-3 mb-4">
        <!-- Base de Apertura -->
        <div class="col-sm-6 col-xl-3">
            <div class="card border-0 shadow-sm p-3 h-100">
                <span class="text-muted extra-small fw-semibold">Base de Apertura</span>
                <h4 class="fw-bold mb-0 text-dark"><?= formatPrice($resumen['monto_apertura'] ?? 0) ?></h4>
                <small class="text-muted extra-small mt-1">Efectivo inicial para cambio</small>
            </div>
        </div>

        <!-- Ventas en Efectivo -->
        <div class="col-sm-6 col-xl-3">
            <div class="card border-0 shadow-sm p-3 h-100">
                <span class="text-muted extra-small fw-semibold">Ventas en Efectivo</span>
                <h4 class="fw-bold mb-0 text-success"><?= formatPrice($resumen['ventas_efectivo'] ?? 0) ?></h4>
                <small class="text-muted extra-small mt-1">Ingresado al cajón por POS</small>
            </div>
        </div>

        <!-- Ventas Digitales -->
        <div class="col-sm-6 col-xl-3">
            <div class="card border-0 shadow-sm p-3 h-100">
                <span class="text-muted extra-small fw-semibold">Ventas Digitales (Nequi/Tarj.)</span>
                <h4 class="fw-bold mb-0 text-primary"><?= formatPrice($resumen['ventas_digitales'] ?? 0) ?></h4>
                <small class="text-muted extra-small mt-1">No suma al efectivo físico</small>
            </div>
        </div>

        <!-- Efectivo Esperado en Cajón -->
        <div class="col-sm-6 col-xl-3">
            <div class="card border-0 shadow-sm p-3 h-100 bg-dark-navy text-white">
                <span class="text-white-50 extra-small fw-semibold">Efectivo Esperado en Cajón</span>
                <h4 class="fw-bold mb-0 text-white" id="montoEsperadoArqueo" data-esperado="<?= $resumen['efectivo_esperado'] ?? 0 ?>">
                    <?= formatPrice($resumen['efectivo_esperado'] ?? 0) ?>
                </h4>
                <small class="text-white-50 extra-small mt-1">Base + Ventas Efect. + Ingresos - Egresos</small>
            </div>
        </div>
    </div>

    <!-- Cierre de Caja y Desglose -->
    <div class="row g-4 mb-4">
        <!-- Formulario de Cierre de Caja -->
        <div class="col-lg-6">
            <div class="card border-0 shadow-sm p-4 h-100 bg-white">
                <h6 class="fw-bold text-dark mb-3 d-flex align-items-center gap-2">
                    <i class="bi bi-lock-fill text-danger"></i> Cierre de Turno y Cuadre Físico
                </h6>
                <form method="POST" action="<?= url('caja', 'cerrar') ?>" onsubmit="confirmarAccion(event, '¿Cerrar Turno de Caja?', 'Una vez cerrada la caja, se guardará el balance y se bloqueará el turno actual.')">
                    <input type="hidden" name="caja_id" value="<?= $cajaActiva['id'] ?>">

                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Dinero Físico Contado en Cajón ($) *</label>
                        <div class="input-group input-group-lg">
                            <span class="input-group-text">$</span>
                            <input type="number" step="100" min="0" name="monto_cierre_real" id="inputMontoReal" class="form-control fw-bold" placeholder="0" required oninput="calcularDiferenciaArqueo(this.value)">
                        </div>
                    </div>

                    <!-- Indicador de Diferencia / Cuadre -->
                    <div id="resultadoDiferenciaArqueo" class="alert alert-light border p-3 rounded-3 d-none mb-3">
                        <div class="d-flex justify-content-between align-items-center">
                            <span class="small fw-semibold text-muted">Diferencia de Caja:</span>
                            <span class="fw-bold fs-5" id="textoDiferencia">$ 0</span>
                        </div>
                        <small class="text-muted d-block mt-1" id="explicacionDiferencia"></small>
                    </div>

                    <div class="mb-4">
                        <label class="form-label small fw-semibold">Observaciones del Cierre</label>
                        <textarea name="observaciones" class="form-control" rows="2" placeholder="Ej: Cuadre exacto / Faltante justificado por cambio de billete..."></textarea>
                    </div>

                    <button type="submit" class="btn btn-danger w-100 py-2 fw-bold shadow-sm">
                        <i class="bi bi-check-circle me-1"></i> Confirmar Cierre y Arqueo
                    </button>
                </form>
            </div>
        </div>

        <!-- Gastos e Ingresos Menores en Turno -->
        <div class="col-lg-6">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
                    <h6 class="fw-bold mb-0 text-dark">Movimientos Menores del Turno</h6>
                    <span class="badge bg-light text-dark border"><?= count($movimientos) ?> registros</span>
                </div>
                <div class="table-responsive" style="max-height: 280px; overflow-y: auto;">
                    <table class="table align-middle mb-0 table-hover small">
                        <thead class="table-light extra-small text-uppercase text-muted">
                            <tr>
                                <th>Tipo</th>
                                <th>Concepto</th>
                                <th>Monto</th>
                                <th>Hora</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($movimientos)): ?>
                                <tr>
                                    <td colspan="4" class="text-center py-4 text-muted">No hay gastos o ingresos extras registrados en este turno.</td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($movimientos as $m): ?>
                                    <tr>
                                        <td>
                                            <?php if ($m['tipo'] === 'EGRESO_GASTO'): ?>
                                                <span class="badge bg-danger-subtle text-danger">GASTO</span>
                                            <?php else: ?>
                                                <span class="badge bg-success-subtle text-success">INGRESO</span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?= htmlspecialchars($m['concepto']) ?></td>
                                        <td class="fw-bold <?= $m['tipo'] === 'EGRESO_GASTO' ? 'text-danger' : 'text-success' ?>">
                                            <?= ($m['tipo'] === 'EGRESO_GASTO' ? '-' : '+') . formatPrice($m['monto']) ?>
                                        </td>
                                        <td class="text-muted extra-small"><?= date('H:i', strtotime($m['fecha'])) ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>

<!-- Historial de Arqueos Pasados -->
<div class="card border-0 shadow-sm">
    <div class="card-header bg-white py-3">
        <h6 class="fw-bold mb-0 text-dark">Historial de Cierres de Caja Anteriores</h6>
    </div>
    <div class="table-responsive">
        <table class="table align-middle mb-0 table-hover small">
            <thead class="table-light extra-small text-uppercase text-muted">
                <tr>
                    <th>Turno</th>
                    <th>Cajero</th>
                    <th>Apertura</th>
                    <th>Cierre</th>
                    <th>Base</th>
                    <th>Esperado</th>
                    <th>Real Contado</th>
                    <th>Diferencia</th>
                    <th>Estado</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($historialCierres)): ?>
                    <tr>
                        <td colspan="9" class="text-center py-4 text-muted">No hay historial de cierres previos.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($historialCierres as $c): ?>
                        <tr>
                            <td class="fw-bold">#<?= $c['id'] ?></td>
                            <td><?= htmlspecialchars($c['usuario_nombre']) ?></td>
                            <td class="extra-small text-muted"><?= date('d/m/Y H:i', strtotime($c['fecha_apertura'])) ?></td>
                            <td class="extra-small text-muted"><?= $c['fecha_cierre'] ? date('d/m/Y H:i', strtotime($c['fecha_cierre'])) : 'En curso' ?></td>
                            <td><?= formatPrice($c['monto_apertura']) ?></td>
                            <td><?= formatPrice($c['monto_cierre_esperado'] ?? 0) ?></td>
                            <td class="fw-bold"><?= formatPrice($c['monto_cierre_real'] ?? 0) ?></td>
                            <td>
                                <?php 
                                    $dif = (float)($c['diferencia'] ?? 0);
                                    if ($dif == 0) {
                                        echo '<span class="badge bg-success-subtle text-success">Exacto ($0)</span>';
                                    } elseif ($dif > 0) {
                                        echo '<span class="badge bg-info-subtle text-info">Sobrante +' . formatPrice($dif) . '</span>';
                                    } else {
                                        echo '<span class="badge bg-danger-subtle text-danger">Faltante ' . formatPrice($dif) . '</span>';
                                    }
                                ?>
                            </td>
                            <td>
                                <span class="badge <?= $c['estado'] === 'ABIERTA' ? 'bg-success' : 'bg-secondary' ?> extra-small">
                                    <?= $c['estado'] ?>
                                </span>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Modal Gasto Menor -->
<div class="modal fade" id="modalGasto" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title fw-bold">Registrar Gasto Menor / Salida de Efectivo</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" action="<?= url('caja', 'movimiento') ?>">
                <input type="hidden" name="caja_id" value="<?= $cajaActiva['id'] ?? '' ?>">
                <input type="hidden" name="tipo" value="EGRESO_GASTO">
                <div class="modal-body p-4">
                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Monto del Gasto ($) *</label>
                        <input type="number" step="100" min="100" name="monto" class="form-control form-control-lg fw-bold" placeholder="5000" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Concepto / Motivo *</label>
                        <input type="text" name="concepto" class="form-control" placeholder="Ej: Compra de cinta de moño / Pago domicilio urgente" required>
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-danger fw-semibold">Registrar Salida</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal Ingreso Extra -->
<div class="modal fade" id="modalIngreso" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow">
            <div class="modal-header bg-success text-white">
                <h5 class="modal-title fw-bold">Registrar Ingreso de Efectivo Extra</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" action="<?= url('caja', 'movimiento') ?>">
                <input type="hidden" name="caja_id" value="<?= $cajaActiva['id'] ?? '' ?>">
                <input type="hidden" name="tipo" value="INGRESO">
                <div class="modal-body p-4">
                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Monto a Ingresar ($) *</label>
                        <input type="number" step="100" min="100" name="monto" class="form-control form-control-lg fw-bold" placeholder="20000" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Concepto / Motivo *</label>
                        <input type="text" name="concepto" class="form-control" placeholder="Ej: Más sencillo / Aporte del dueño" required>
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-success fw-semibold">Registrar Ingreso</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    function calcularDiferenciaArqueo(valorReal) {
        const esperadoEl = document.getElementById('montoEsperadoArqueo');
        if (!esperadoEl) return;

        const esperado = parseFloat(esperadoEl.getAttribute('data-esperado') || '0');
        const real = parseFloat(valorReal) || 0;
        const dif = real - esperado;

        const cont = document.getElementById('resultadoDiferenciaArqueo');
        const txtDif = document.getElementById('textoDiferencia');
        const txtExp = document.getElementById('explicacionDiferencia');

        cont.classList.remove('d-none');

        if (dif === 0) {
            txtDif.className = 'fw-bold fs-5 text-success';
            txtDif.innerText = '$ 0 (Cuadre Exacto)';
            txtExp.innerText = 'El efectivo contado coincide exactamente con el balance del sistema.';
        } else if (dif > 0) {
            txtDif.className = 'fw-bold fs-5 text-info';
            txtDif.innerText = '+ ' + formatMoney(dif) + ' (Sobrante)';
            txtExp.innerText = 'Hay más dinero físico en el cajón de lo registrado por el sistema.';
        } else {
            txtDif.className = 'fw-bold fs-5 text-danger';
            txtDif.innerText = formatMoney(dif) + ' (Faltante)';
            txtExp.innerText = 'Falta dinero en el cajón respecto a las ventas y gastos registrados.';
        }
    }
</script>

<?php require_once __DIR__ . '/../layouts/footer.php'; ?>
