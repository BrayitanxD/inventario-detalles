<?php
$pageTitle = 'Informes & Ganancias - Peluches & Detalles';
require_once __DIR__ . '/../layouts/header.php';

$margenGlobal = ($totalCostoPeriodo > 0) ? round((($totalGananciaPeriodo) / $totalCostoPeriodo) * 100, 1) : 0;
?>

<div class="d-flex flex-wrap justify-content-between align-items-center mb-4 gap-3">
    <div>
        <h3 class="fw-bold text-dark mb-1">Informes Financieros & Inventario</h3>
        <p class="text-muted small mb-0">Análisis de ventas, rentabilidad bruta, rotación de productos y valorización.</p>
    </div>
    <button class="btn btn-outline-dark btn-sm d-flex align-items-center gap-1" onclick="window.print()">
        <i class="bi bi-printer"></i> Imprimir Reporte
    </button>
</div>

<!-- Filtro por Rango de Fechas -->
<div class="card border-0 shadow-sm mb-4">
    <div class="card-body p-3">
        <form method="GET" action="<?= BASE_URL ?>/index.php" class="row g-2 align-items-end">
            <input type="hidden" name="c" value="reporte">
            <input type="hidden" name="a" value="index">

            <div class="col-md-4">
                <label class="form-label extra-small fw-semibold text-muted mb-1">Fecha Inicio</label>
                <input type="date" name="fecha_inicio" class="form-control form-control-sm" value="<?= htmlspecialchars($fechaInicio) ?>" required>
            </div>

            <div class="col-md-4">
                <label class="form-label extra-small fw-semibold text-muted mb-1">Fecha Fin</label>
                <input type="date" name="fecha_fin" class="form-control form-control-sm" value="<?= htmlspecialchars($fechaFin) ?>" required>
            </div>

            <div class="col-md-4 d-flex gap-2">
                <button type="submit" class="btn btn-dark btn-sm flex-grow-1">Generar Reporte</button>
                <a href="<?= url('reporte', 'index', ['fecha_inicio' => date('Y-m-01'), 'fecha_fin' => date('Y-m-d')]) ?>" class="btn btn-outline-secondary btn-sm">Mes Actual</a>
            </div>
        </form>
    </div>
</div>

<!-- Métricas de Rentabilidad del Período -->
<div class="row g-3 mb-4">
    <div class="col-md-4">
        <div class="card border-0 shadow-sm p-3">
            <span class="text-muted extra-small fw-semibold">Ingresos por Ventas (Período)</span>
            <h3 class="fw-bold mb-0 text-primary"><?= formatPrice($totalVentasPeriodo) ?></h3>
            <small class="text-muted extra-small mt-1"><?= count($ventasRango) ?> facturas completadas</small>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card border-0 shadow-sm p-3">
            <span class="text-muted extra-small fw-semibold">Costo de Mercancía Vendida</span>
            <h3 class="fw-bold mb-0 text-secondary"><?= formatPrice($totalCostoPeriodo) ?></h3>
            <small class="text-muted extra-small mt-1">Costo de adquisición de los productos</small>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card border-0 shadow-sm p-3 bg-pink-light">
            <span class="text-pink extra-small fw-bold">Ganancia Bruta Estimada</span>
            <h3 class="fw-bold mb-0 text-pink"><?= formatPrice($totalGananciaPeriodo) ?></h3>
            <small class="text-pink extra-small mt-1 fw-semibold">+<?= $margenGlobal ?>% margen sobre costo</small>
        </div>
    </div>
</div>

<!-- Pestañas de Análisis -->
<ul class="nav nav-pills mb-3" id="reportTabs" role="tablist">
    <li class="nav-item">
        <button class="nav-link active" data-bs-toggle="pill" data-bs-target="#tabVentas">Detalle de Ventas</button>
    </li>
    <li class="nav-item">
        <button class="nav-link" data-bs-toggle="pill" data-bs-target="#tabInventario">Inventario Valorizado</button>
    </li>
    <li class="nav-item">
        <button class="nav-link" data-bs-toggle="pill" data-bs-target="#tabTop">Top Productos Más Vendidos</button>
    </li>
</ul>

<div class="tab-content">
    <!-- Pestaña 1: Ventas y Márgenes -->
    <div class="tab-pane fade show active" id="tabVentas">
        <div class="card border-0 shadow-sm">
            <div class="table-responsive">
                <table class="table align-middle mb-0 table-hover small">
                    <thead class="table-light extra-small text-uppercase text-muted">
                        <tr>
                            <th>Factura</th>
                            <th>Fecha</th>
                            <th>Cliente</th>
                            <th>Método</th>
                            <th>Venta</th>
                            <th>Costo</th>
                            <th>Ganancia</th>
                            <th class="text-center">Ticket</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($ventasRango)): ?>
                            <tr>
                                <td colspan="8" class="text-center py-4 text-muted">No se registraron ventas en el rango de fechas seleccionado.</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($ventasRango as $vr): ?>
                                <tr>
                                    <td class="fw-bold font-monospace"><?= htmlspecialchars($vr['numero_factura']) ?></td>
                                    <td class="text-muted extra-small"><?= date('d/m/Y H:i', strtotime($vr['fecha'])) ?></td>
                                    <td><?= htmlspecialchars($vr['cliente_nombre']) ?></td>
                                    <td><span class="badge bg-light text-dark border"><?= htmlspecialchars($vr['metodo_pago']) ?></span></td>
                                    <td class="fw-bold"><?= formatPrice($vr['total']) ?></td>
                                    <td class="text-muted"><?= formatPrice($vr['costo_total_venta']) ?></td>
                                    <td class="fw-bold text-success">+<?= formatPrice($vr['ganancia_estimada']) ?></td>
                                    <td class="text-center">
                                        <a href="<?= url('venta', 'factura', ['id' => $vr['id']]) ?>" target="_blank" class="btn btn-outline-secondary btn-sm py-0 px-2">
                                            <i class="bi bi-printer"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Pestaña 2: Inventario Valorizado -->
    <div class="tab-pane fade" id="tabInventario">
        <div class="card border-0 shadow-sm">
            <div class="table-responsive">
                <table class="table align-middle mb-0 table-hover small">
                    <thead class="table-light extra-small text-uppercase text-muted">
                        <tr>
                            <th>Categoría</th>
                            <th>Variedad de Items</th>
                            <th>Total Unidades</th>
                            <th>Valor al Costo</th>
                            <th>Valor a Precio Venta</th>
                            <th>Utilidad Proyectada</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                            $totalValCosto = 0;
                            $totalValVenta = 0;
                        ?>
                        <?php foreach ($inventarioVal as $iv): ?>
                            <?php 
                                $totalValCosto += (float)$iv['valor_costo'];
                                $totalValVenta += (float)$iv['valor_venta'];
                            ?>
                            <tr>
                                <td class="fw-bold text-dark"><?= htmlspecialchars($iv['categoria']) ?></td>
                                <td><?= $iv['cantidad_items'] ?> referencias</td>
                                <td><span class="badge bg-primary-subtle text-primary fw-bold"><?= number_format($iv['total_unidades'] ?? 0) ?> u.</span></td>
                                <td class="text-muted"><?= formatPrice($iv['valor_costo'] ?? 0) ?></td>
                                <td class="fw-bold text-dark"><?= formatPrice($iv['valor_venta'] ?? 0) ?></td>
                                <td class="fw-bold text-success">+<?= formatPrice($iv['ganancia_potencial'] ?? 0) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                    <tfoot class="table-light fw-bold">
                        <tr>
                            <td colspan="3">TOTAL INVENTARIO EN TIENDA:</td>
                            <td class="text-muted"><?= formatPrice($totalValCosto) ?></td>
                            <td class="text-primary"><?= formatPrice($totalValVenta) ?></td>
                            <td class="text-success">+<?= formatPrice($totalValVenta - $totalValCosto) ?></td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>

    <!-- Pestaña 3: Top Productos -->
    <div class="tab-pane fade" id="tabTop">
        <div class="card border-0 shadow-sm">
            <div class="table-responsive">
                <table class="table align-middle mb-0 table-hover small">
                    <thead class="table-light extra-small text-uppercase text-muted">
                        <tr>
                            <th>#</th>
                            <th>Producto</th>
                            <th>Categoría</th>
                            <th>Código</th>
                            <th>Unidades Vendidas</th>
                            <th>Ingresos Generados</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($topProductos)): ?>
                            <tr>
                                <td colspan="6" class="text-center py-4 text-muted">Aún no hay suficientes ventas acumuladas.</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($topProductos as $idx => $tp): ?>
                                <tr>
                                    <td class="fw-bold"><?= $idx + 1 ?></td>
                                    <td class="fw-bold text-dark"><?= htmlspecialchars($tp['nombre']) ?></td>
                                    <td><span class="badge bg-light text-secondary border"><?= htmlspecialchars($tp['categoria_nombre']) ?></span></td>
                                    <td class="text-muted font-monospace extra-small"><?= htmlspecialchars($tp['codigo_barras'] ?? 'S/C') ?></td>
                                    <td><span class="badge bg-success fw-bold"><?= $tp['total_vendido'] ?> unidades</span></td>
                                    <td class="fw-bold text-primary"><?= formatPrice($tp['total_ingreso']) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../layouts/footer.php'; ?>
