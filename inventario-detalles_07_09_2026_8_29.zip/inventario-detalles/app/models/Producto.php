<?php
// Modelo de Producto

require_once __DIR__ . '/../config/Database.php';

class Producto {
    private PDO $db;

    public function __construct() {
        $this->db = Database::getConnection();
    }

    public function getAll(?int $categoria_id = null, ?string $busqueda = null): array {
        $sql = "
            SELECT p.*, c.nombre as categoria_nombre 
            FROM productos p 
            JOIN categorias c ON p.categoria_id = c.id 
            WHERE p.estado = 1
        ";
        $params = [];

        if (!empty($categoria_id)) {
            $sql .= " AND p.categoria_id = :categoria_id";
            $params[':categoria_id'] = $categoria_id;
        }

        if (!empty($busqueda)) {
            $sql .= " AND (p.nombre LIKE :busqueda OR p.codigo_barras LIKE :busqueda OR p.descripcion LIKE :busqueda)";
            $params[':busqueda'] = '%' . trim($busqueda) . '%';
        }

        $sql .= " ORDER BY p.id DESC";
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public function getById(int $id): ?array {
        $stmt = $this->db->prepare("
            SELECT p.*, c.nombre as categoria_nombre 
            FROM productos p 
            JOIN categorias c ON p.categoria_id = c.id 
            WHERE p.id = :id AND p.estado = 1
        ");
        $stmt->execute([':id' => $id]);
        return $stmt->fetch() ?: null;
    }

    public function getByBarcode(string $barcode): ?array {
        $stmt = $this->db->prepare("
            SELECT p.*, c.nombre as categoria_nombre 
            FROM productos p 
            JOIN categorias c ON p.categoria_id = c.id 
            WHERE p.codigo_barras = :code AND p.estado = 1 
            LIMIT 1
        ");
        $stmt->execute([':code' => trim($barcode)]);
        return $stmt->fetch() ?: null;
    }

    /**
     * Búsqueda en vivo para el Punto de Venta (POS) con AJAX
     */
    public function searchLive(string $term): array {
        $term = '%' . trim($term) . '%';
        $stmt = $this->db->prepare("
            SELECT p.id, p.codigo_barras, p.nombre, p.precio_venta, p.stock_actual, p.stock_minimo, p.imagen, c.nombre as categoria_nombre
            FROM productos p 
            JOIN categorias c ON p.categoria_id = c.id 
            WHERE p.estado = 1 AND (p.nombre LIKE :term1 OR p.codigo_barras LIKE :term2)
            ORDER BY p.nombre ASC
            LIMIT 15
        ");
        $stmt->execute([':term1' => $term, ':term2' => $term]);
        return $stmt->fetchAll();
    }

    public function crear(array $data): int {
        $sql = "INSERT INTO productos (
            codigo_barras, nombre, descripcion, categoria_id, 
            precio_compra, precio_venta, stock_actual, stock_minimo, 
            ubicacion, imagen
        ) VALUES (
            :codigo_barras, :nombre, :descripcion, :categoria_id, 
            :precio_compra, :precio_venta, :stock_actual, :stock_minimo, 
            :ubicacion, :imagen
        )";

        $stmt = $this->db->prepare($sql);
        $stmt->execute([
            ':codigo_barras' => !empty($data['codigo_barras']) ? trim($data['codigo_barras']) : null,
            ':nombre'        => trim($data['nombre']),
            ':descripcion'   => !empty($data['descripcion']) ? trim($data['descripcion']) : null,
            ':categoria_id'  => (int)$data['categoria_id'],
            ':precio_compra' => (float)$data['precio_compra'],
            ':precio_venta'  => (float)$data['precio_venta'],
            ':stock_actual'  => (int)$data['stock_actual'],
            ':stock_minimo'  => (int)($data['stock_minimo'] ?? 5),
            ':ubicacion'     => !empty($data['ubicacion']) ? trim($data['ubicacion']) : null,
            ':imagen'        => !empty($data['imagen']) ? $data['imagen'] : null,
        ]);

        return (int)$this->db->lastInsertId();
    }

    public function actualizar(int $id, array $data): bool {
        $sql = "UPDATE productos SET 
            codigo_barras = :codigo_barras,
            nombre = :nombre,
            descripcion = :descripcion,
            categoria_id = :categoria_id,
            precio_compra = :precio_compra,
            precio_venta = :precio_venta,
            stock_minimo = :stock_minimo,
            ubicacion = :ubicacion";

        if (!empty($data['imagen'])) {
            $sql .= ", imagen = :imagen";
        }

        $sql .= " WHERE id = :id";

        $params = [
            ':codigo_barras' => !empty($data['codigo_barras']) ? trim($data['codigo_barras']) : null,
            ':nombre'        => trim($data['nombre']),
            ':descripcion'   => !empty($data['descripcion']) ? trim($data['descripcion']) : null,
            ':categoria_id'  => (int)$data['categoria_id'],
            ':precio_compra' => (float)$data['precio_compra'],
            ':precio_venta'  => (float)$data['precio_venta'],
            ':stock_minimo'  => (int)($data['stock_minimo'] ?? 5),
            ':ubicacion'     => !empty($data['ubicacion']) ? trim($data['ubicacion']) : null,
            ':id'            => $id
        ];

        if (!empty($data['imagen'])) {
            $params[':imagen'] = $data['imagen'];
        }

        $stmt = $this->db->prepare($sql);
        return $stmt->execute($params);
    }

    public function eliminar(int $id): bool {
        $stmt = $this->db->prepare("UPDATE productos SET estado = 0 WHERE id = :id");
        return $stmt->execute([':id' => $id]);
    }

    public function getBajoStock(): array {
        $stmt = $this->db->query("
            SELECT p.*, c.nombre as categoria_nombre 
            FROM productos p 
            JOIN categorias c ON p.categoria_id = c.id 
            WHERE p.estado = 1 AND p.stock_actual <= p.stock_minimo 
            ORDER BY p.stock_actual ASC
        ");
        return $stmt->fetchAll();
    }

    public function getEstadisticas(): array {
        $stmt = $this->db->query("
            SELECT 
                COUNT(*) as total_productos,
                SUM(stock_actual) as total_unidades,
                SUM(stock_actual * precio_compra) as total_valor_costo,
                SUM(stock_actual * precio_venta) as total_valor_venta,
                SUM(CASE WHEN stock_actual <= stock_minimo THEN 1 ELSE 0 END) as productos_bajo_stock
            FROM productos 
            WHERE estado = 1
        ");
        return $stmt->fetch() ?: [
            'total_productos' => 0,
            'total_unidades' => 0,
            'total_valor_costo' => 0,
            'total_valor_venta' => 0,
            'productos_bajo_stock' => 0
        ];
    }
}
