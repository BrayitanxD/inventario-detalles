<?php
// Modelo de Reportes y Estadísticas

require_once __DIR__ . '/../config/Database.php';

class Reporte {
    private PDO $db;

    public function __construct() {
        $this->db = Database::getConnection();
    }

    /**
     * Resumen métricas clave para Dashboard
     */
    public function getMetricasDashboard(): array {
        // Ventas de hoy
        $stmtHoy = $this->db->query("
            SELECT COALESCE(SUM(total), 0) as total_hoy, COUNT(id) as transacciones_hoy 
            FROM ventas 
            WHERE DATE(fecha) = CURDATE() AND estado = 'COMPLETADA'
        ");
        $hoy = $stmtHoy->fetch();

        // Ventas del mes
        $stmtMes = $this->db->query("
            SELECT COALESCE(SUM(total), 0) as total_mes, COUNT(id) as transacciones_mes 
            FROM ventas 
            WHERE MONTH(fecha) = MONTH(CURDATE()) AND YEAR(fecha) = YEAR(CURDATE()) AND estado = 'COMPLETADA'
        ");
        $mes = $stmtMes->fetch();

        // Total productos y bajo stock
        $stmtProd = $this->db->query("
            SELECT 
                COUNT(id) as total_productos,
                COALESCE(SUM(stock_actual), 0) as total_unidades,
                SUM(CASE WHEN stock_actual <= stock_minimo THEN 1 ELSE 0 END) as productos_alerta
            FROM productos 
            WHERE estado = 1
        ");
        $prod = $stmtProd->fetch();

        return [
            'ventas_hoy'          => (float)($hoy['total_hoy'] ?? 0),
            'transacciones_hoy'   => (int)($hoy['transacciones_hoy'] ?? 0),
            'ventas_mes'          => (float)($mes['total_mes'] ?? 0),
            'transacciones_mes'   => (int)($mes['transacciones_mes'] ?? 0),
            'total_productos'     => (int)($prod['total_productos'] ?? 0),
            'total_unidades'      => (int)($prod['total_unidades'] ?? 0),
            'productos_alerta'    => (int)($prod['productos_alerta'] ?? 0),
        ];
    }

    /**
     * Ventas de los últimos 7 días
     */
    public function getVentasUltimosDias(int $dias = 7): array {
        $stmt = $this->db->prepare("
            SELECT DATE(fecha) as dia, SUM(total) as total_dia, COUNT(id) as conteo
            FROM ventas 
            WHERE fecha >= DATE_SUB(CURDATE(), INTERVAL :dias DAY) AND estado = 'COMPLETADA'
            GROUP BY DATE(fecha)
            ORDER BY DATE(fecha) ASC
        ");
        $stmt->bindValue(':dias', $dias, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    /**
     * Top productos más vendidos
     */
    public function getTopProductos(int $limit = 5): array {
        $stmt = $this->db->prepare("
            SELECT p.nombre, p.codigo_barras, c.nombre as categoria_nombre, 
                   SUM(d.cantidad) as total_vendido, 
                   SUM(d.subtotal) as total_ingreso
            FROM ventas_detalle d
            JOIN ventas v ON d.venta_id = v.id
            JOIN productos p ON d.producto_id = p.id
            JOIN categorias c ON p.categoria_id = c.id
            WHERE v.estado = 'COMPLETADA'
            GROUP BY p.id
            ORDER BY total_vendido DESC
            LIMIT :limite
        ");
        $stmt->bindValue(':limite', $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    /**
     * Reporte de ventas con rango de fechas y cálculo de margen de ganancia
     */
    public function getReporteVentasRango(string $fechaInicio, string $fechaFin): array {
        $stmt = $this->db->prepare("
            SELECT v.*, u.nombre as usuario_nombre,
                   SUM(d.costo_unitario * d.cantidad) as costo_total_venta,
                   (v.total - SUM(d.costo_unitario * d.cantidad)) as ganancia_estimada
            FROM ventas v
            JOIN usuarios u ON v.usuario_id = u.id
            LEFT JOIN ventas_detalle d ON v.id = d.venta_id
            WHERE DATE(v.fecha) BETWEEN :ini AND :fin AND v.estado = 'COMPLETADA'
            GROUP BY v.id
            ORDER BY v.fecha DESC
        ");
        $stmt->execute([':ini' => $fechaInicio, ':fin' => $fechaFin]);
        return $stmt->fetchAll();
    }

    /**
     * Reporte de inventario valorizado por categoría
     */
    public function getInventarioValorizado(): array {
        $stmt = $this->db->query("
            SELECT c.nombre as categoria,
                   COUNT(p.id) as cantidad_items,
                   SUM(p.stock_actual) as total_unidades,
                   SUM(p.stock_actual * p.precio_compra) as valor_costo,
                   SUM(p.stock_actual * p.precio_venta) as valor_venta,
                   (SUM(p.stock_actual * p.precio_venta) - SUM(p.stock_actual * p.precio_compra)) as ganancia_potencial
            FROM categorias c
            LEFT JOIN productos p ON c.id = p.categoria_id AND p.estado = 1
            WHERE c.estado = 1
            GROUP BY c.id
            ORDER BY valor_venta DESC
        ");
        return $stmt->fetchAll();
    }
}
