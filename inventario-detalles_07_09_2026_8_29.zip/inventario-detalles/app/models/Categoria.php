<?php
// Modelo de Categoría

require_once __DIR__ . '/../config/Database.php';

class Categoria {
    private PDO $db;

    public function __construct() {
        $this->db = Database::getConnection();
    }

    public function getAll(): array {
        $stmt = $this->db->query("
            SELECT c.*, COUNT(p.id) as total_productos 
            FROM categorias c 
            LEFT JOIN productos p ON c.id = p.categoria_id AND p.estado = 1
            WHERE c.estado = 1 
            GROUP BY c.id 
            ORDER BY c.nombre ASC
        ");
        return $stmt->fetchAll();
    }

    public function getById(int $id): ?array {
        $stmt = $this->db->prepare("SELECT * FROM categorias WHERE id = :id AND estado = 1");
        $stmt->execute([':id' => $id]);
        return $stmt->fetch() ?: null;
    }

    public function crear(string $nombre, ?string $descripcion = null): bool {
        $stmt = $this->db->prepare("INSERT INTO categorias (nombre, descripcion) VALUES (:nombre, :descripcion)");
        return $stmt->execute([
            ':nombre'      => trim($nombre),
            ':descripcion' => $descripcion ? trim($descripcion) : null
        ]);
    }

    public function actualizar(int $id, string $nombre, ?string $descripcion = null): bool {
        $stmt = $this->db->prepare("UPDATE categorias SET nombre = :nombre, descripcion = :descripcion WHERE id = :id");
        return $stmt->execute([
            ':nombre'      => trim($nombre),
            ':descripcion' => $descripcion ? trim($descripcion) : null,
            ':id'          => $id
        ]);
    }

    public function eliminar(int $id): bool {
        // Soft delete para mantener integridad histórica
        $stmt = $this->db->prepare("UPDATE categorias SET estado = 0 WHERE id = :id");
        return $stmt->execute([':id' => $id]);
    }
}
