<?php
// Modelo de Usuario

require_once __DIR__ . '/../config/Database.php';

class Usuario {
    private PDO $db;

    public function __construct() {
        $this->db = Database::getConnection();
    }

    public function autenticar(string $username, string $password): ?array {
        $stmt = $this->db->prepare("SELECT * FROM usuarios WHERE usuario = :usuario AND estado = 1 LIMIT 1");
        $stmt->execute([':usuario' => $username]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            return $user;
        }
        return null;
    }

    public function getById(int $id): ?array {
        $stmt = $this->db->prepare("SELECT id, nombre, usuario, rol, estado, creado_en FROM usuarios WHERE id = :id");
        $stmt->execute([':id' => $id]);
        return $stmt->fetch() ?: null;
    }

    public function getAll(): array {
        $stmt = $this->db->query("SELECT id, nombre, usuario, rol, estado, creado_en FROM usuarios ORDER BY nombre ASC");
        return $stmt->fetchAll();
    }

    public function crear(string $nombre, string $usuario, string $password, string $rol): bool {
        $hash = password_hash($password, PASSWORD_BCRYPT);
        $stmt = $this->db->prepare("INSERT INTO usuarios (nombre, usuario, password, rol) VALUES (:nombre, :usuario, :password, :rol)");
        return $stmt->execute([
            ':nombre'   => $nombre,
            ':usuario'  => $usuario,
            ':password' => $hash,
            ':rol'      => $rol
        ]);
    }
}
