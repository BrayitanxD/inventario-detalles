<?php
// Modelo de Ventas y Facturación

require_once __DIR__ . '/../config/Database.php';

class Venta {
    private PDO $db;

    public function __construct() {
        $this->db = Database::getConnection();
    }

    /**
     * Genera el siguiente número consecutivo de factura
     */
    public function generarNumeroFactura(): string {
        $stmt = $this->db->query("SELECT MAX(id) as max_id FROM ventas");
        $res = $stmt->fetch();
        $nextNum = ((int)($res['max_id'] ?? 0)) + 1;
        return 'FAC-' . str_pad((string)$nextNum, 6, '0', STR_PAD_LEFT);
    }

    /**
     * Registra una venta completa en una transacción ACID
     */
    public function procesarVenta(array $ventaData, array $items): array {
        if (empty($items)) {
            return ['success' => false, 'message' => 'El carrito de venta está vacío.'];
        }

        try {
            $this->db->beginTransaction();

            $numeroFactura = $this->generarNumeroFactura();

            // 1. Insertar encabezado de la venta
            $sqlVenta = "INSERT INTO ventas (
                numero_factura, cliente_nombre, cliente_documento, cliente_telefono,
                caja_id, usuario_id, metodo_pago, subtotal, descuento, total,
                monto_recibido, cambio, estado
            ) VALUES (
                :numero_factura, :cliente_nombre, :cliente_documento, :cliente_telefono,
                :caja_id, :usuario_id, :metodo_pago, :subtotal, :descuento, :total,
                :monto_recibido, :cambio, 'COMPLETADA'
            )";

            $stmtVenta = $this->db->prepare($sqlVenta);
            $stmtVenta->execute([
                ':numero_factura'   => $numeroFactura,
                ':cliente_nombre'   => !empty($ventaData['cliente_nombre']) ? trim($ventaData['cliente_nombre']) : 'Consumidor Final',
                ':cliente_documento'=> !empty($ventaData['cliente_documento']) ? trim($ventaData['cliente_documento']) : null,
                ':cliente_telefono' => !empty($ventaData['cliente_telefono']) ? trim($ventaData['cliente_telefono']) : null,
                ':caja_id'          => !empty($ventaData['caja_id']) ? (int)$ventaData['caja_id'] : null,
                ':usuario_id'       => (int)$ventaData['usuario_id'],
                ':metodo_pago'      => $ventaData['metodo_pago'] ?? 'EFECTIVO',
                ':subtotal'         => (float)$ventaData['subtotal'],
                ':descuento'        => (float)($ventaData['descuento'] ?? 0),
                ':total'            => (float)$ventaData['total'],
                ':monto_recibido'   => (float)($ventaData['monto_recibido'] ?? $ventaData['total']),
                ':cambio'           => (float)($ventaData['cambio'] ?? 0)
            ]);

            $ventaId = (int)$this->db->lastInsertId();

            // Sentencias preparadas para items y actualización de inventario
            $stmtDetalle = $this->db->prepare("
                INSERT INTO ventas_detalle (venta_id, producto_id, cantidad, precio_unitario, costo_unitario, subtotal)
                VALUES (:venta_id, :producto_id, :cantidad, :precio_unitario, :costo_unitario, :subtotal)
            ");

            $stmtCheckStock = $this->db->prepare("SELECT id, nombre, stock_actual, precio_compra FROM productos WHERE id = :id FOR UPDATE");
            $stmtUpdateStock = $this->db->prepare("UPDATE productos SET stock_actual = stock_actual - :cantidad WHERE id = :id");

            $stmtKardex = $this->db->prepare("
                INSERT INTO movimientos_inventario (
                    producto_id, tipo, referencia_id, cantidad, costo_unitario,
                    stock_anterior, stock_posterior, motivo, usuario_id
                ) VALUES (
                    :producto_id, 'SALIDA_VENTA', :ref_id, :cantidad, :costo_unitario,
                    :stock_ant, :stock_post, :motivo, :user_id
                )
            ");

            foreach ($items as $item) {
                $productoId = (int)$item['id'];
                $cantidad = (int)$item['cantidad'];
                $precioUnitario = (float)$item['precio'];
                $subtotalItem = $cantidad * $precioUnitario;

                if ($cantidad <= 0) {
                    continue;
                }

                // Verificar stock actual
                $stmtCheckStock->execute([':id' => $productoId]);
                $prod = $stmtCheckStock->fetch();

                if (!$prod) {
                    throw new Exception("El producto ID {$productoId} no existe.");
                }

                $stockActual = (int)$prod['stock_actual'];
                if ($stockActual < $cantidad) {
                    throw new Exception("Stock insuficiente para '{$prod['nombre']}'. Disponible: {$stockActual}, solicitado: {$cantidad}");
                }

                $costoUnitario = (float)$prod['precio_compra'];
                $nuevoStock = $stockActual - $cantidad;

                // 2. Insertar Detalle
                $stmtDetalle->execute([
                    ':venta_id'        => $ventaId,
                    ':producto_id'     => $productoId,
                    ':cantidad'        => $cantidad,
                    ':precio_unitario' => $precioUnitario,
                    ':costo_unitario'  => $costoUnitario,
                    ':subtotal'        => $subtotalItem
                ]);

                // 3. Descontar Stock
                $stmtUpdateStock->execute([
                    ':cantidad' => $cantidad,
                    ':id'       => $productoId
                ]);

                // 4. Registrar en Kardex
                $stmtKardex->execute([
                    ':producto_id'    => $productoId,
                    ':ref_id'         => $ventaId,
                    ':cantidad'       => $cantidad,
                    ':costo_unitario' => $costoUnitario,
                    ':stock_ant'      => $stockActual,
                    ':stock_post'     => $nuevoStock,
                    ':motivo'         => 'Venta factura ' . $numeroFactura,
                    ':user_id'        => (int)$ventaData['usuario_id']
                ]);
            }

            $this->db->commit();

            return [
                'success'        => true,
                'venta_id'       => $ventaId,
                'numero_factura' => $numeroFactura,
                'message'        => 'Venta registrada con éxito.'
            ];
        } catch (Exception $e) {
            $this->db->rollBack();
            return [
                'success' => false,
                'message' => $e->getMessage()
            ];
        }
    }

    public function getById(int $id): ?array {
        $stmt = $this->db->prepare("
            SELECT v.*, u.nombre as usuario_nombre
            FROM ventas v
            JOIN usuarios u ON v.usuario_id = u.id
            WHERE v.id = :id
        ");
        $stmt->execute([':id' => $id]);
        return $stmt->fetch() ?: null;
    }

    public function getDetalles(int $ventaId): array {
        $stmt = $this->db->prepare("
            SELECT d.*, p.nombre as producto_nombre, p.codigo_barras
            FROM ventas_detalle d
            JOIN productos p ON d.producto_id = p.id
            WHERE d.venta_id = :vid
        ");
        $stmt->execute([':vid' => $ventaId]);
        return $stmt->fetchAll();
    }

    public function getVentas(array $filtros = []): array {
        $sql = "
            SELECT v.*, u.nombre as usuario_nombre
            FROM ventas v
            JOIN usuarios u ON v.usuario_id = u.id
            WHERE 1=1
        ";
        $params = [];

        if (!empty($filtros['fecha_inicio'])) {
            $sql .= " AND DATE(v.fecha) >= :fecha_ini";
            $params[':fecha_ini'] = $filtros['fecha_inicio'];
        }

        if (!empty($filtros['fecha_fin'])) {
            $sql .= " AND DATE(v.fecha) <= :fecha_fin";
            $params[':fecha_fin'] = $filtros['fecha_fin'];
        }

        if (!empty($filtros['metodo_pago'])) {
            $sql .= " AND v.metodo_pago = :metodo";
            $params[':metodo'] = $filtros['metodo_pago'];
        }

        if (!empty($filtros['busqueda'])) {
            $sql .= " AND (v.numero_factura LIKE :b OR v.cliente_nombre LIKE :b OR v.cliente_documento LIKE :b)";
            $params[':b'] = '%' . trim($filtros['busqueda']) . '%';
        }

        $sql .= " ORDER BY v.id DESC LIMIT 200";
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    /**
     * Anular una venta y revertir inventario
     */
    public function anular(int $ventaId, string $motivo, int $usuarioId): bool {
        try {
            $this->db->beginTransaction();

            $venta = $this->getById($ventaId);
            if (!$venta || $venta['estado'] === 'ANULADA') {
                $this->db->rollBack();
                return false;
            }

            // 1. Revertir stock de cada detalle
            $detalles = $this->getDetalles($ventaId);
            $stmtUpdateStock = $this->db->prepare("UPDATE productos SET stock_actual = stock_actual + :cantidad WHERE id = :id");
            $stmtGetStock = $this->db->prepare("SELECT stock_actual, precio_compra FROM productos WHERE id = :id");
            $stmtKardex = $this->db->prepare("
                INSERT INTO movimientos_inventario (
                    producto_id, tipo, referencia_id, cantidad, costo_unitario,
                    stock_anterior, stock_posterior, motivo, usuario_id
                ) VALUES (
                    :producto_id, 'ENTRADA_AJUSTE', :ref_id, :cantidad, :costo_unitario,
                    :stock_ant, :stock_post, :motivo, :user_id
                )
            ");

            foreach ($detalles as $det) {
                $prodId = (int)$det['producto_id'];
                $cant = (int)$det['cantidad'];

                $stmtGetStock->execute([':id' => $prodId]);
                $prod = $stmtGetStock->fetch();

                $stockAnt = (int)$prod['stock_actual'];
                $stockPost = $stockAnt + $cant;

                $stmtUpdateStock->execute([':cantidad' => $cant, ':id' => $prodId]);

                $stmtKardex->execute([
                    ':producto_id'    => $prodId,
                    ':ref_id'         => $ventaId,
                    ':cantidad'       => $cant,
                    ':costo_unitario' => (float)$prod['precio_compra'],
                    ':stock_ant'      => $stockAnt,
                    ':stock_post'     => $stockPost,
                    ':motivo'         => 'Anulación Factura ' . $venta['numero_factura'] . ': ' . trim($motivo),
                    ':user_id'        => $usuarioId
                ]);
            }

            // 2. Marcar venta como ANULADA
            $stmtAnular = $this->db->prepare("UPDATE ventas SET estado = 'ANULADA' WHERE id = :id");
            $stmtAnular->execute([':id' => $ventaId]);

            $this->db->commit();
            return true;
        } catch (Exception $e) {
            $this->db->rollBack();
            return false;
        }
    }
}
