<?php
// Modelo de Movimientos de Inventario (Entradas, Salidas, Mermas, Kardex)

require_once __DIR__ . '/../config/Database.php';

class Movimiento {
    private PDO $db;

    public function __construct() {
        $this->db = Database::getConnection();
    }

    /**
     * Registra un movimiento de entrada o salida con integridad transaccional
     */
    public function registrar(
        int $producto_id,
        string $tipo, // ENTRADA_COMPRA, ENTRADA_AJUSTE, SALIDA_MERMA, SALIDA_USO_INTERNO, SALIDA_VENTA
        int $cantidad,
        float $costo_unitario,
        string $motivo,
        int $usuario_id,
        ?int $referencia_id = null,
        bool $actualizar_costo = false
    ): bool {
        try {
            $this->db->beginTransaction();

            // 1. Obtener stock actual con bloqueo FOR UPDATE para concurrencia
            $stmt = $this->db->prepare("SELECT stock_actual, precio_compra FROM productos WHERE id = :id FOR UPDATE");
            $stmt->execute([':id' => $producto_id]);
            $producto = $stmt->fetch();

            if (!$producto) {
                $this->db->rollBack();
                return false;
            }

            $stock_anterior = (int)$producto['stock_actual'];
            $stock_posterior = $stock_anterior;

            if (str_starts_with($tipo, 'ENTRADA')) {
                $stock_posterior += $cantidad;
            } elseif (str_starts_with($tipo, 'SALIDA')) {
                if ($stock_anterior < $cantidad && $tipo !== 'SALIDA_VENTA') {
                    // No hay suficiente stock para la merma/salida
                    $this->db->rollBack();
                    return false;
                }
                $stock_posterior = max(0, $stock_anterior - $cantidad);
            }

            // 2. Actualizar stock del producto
            $sqlUpdate = "UPDATE productos SET stock_actual = :nuevo_stock";
            $updateParams = [
                ':nuevo_stock' => $stock_posterior,
                ':id'          => $producto_id
            ];

            if ($actualizar_costo && $costo_unitario > 0) {
                $sqlUpdate .= ", precio_compra = :nuevo_costo";
                $updateParams[':nuevo_costo'] = $costo_unitario;
            }

            $sqlUpdate .= " WHERE id = :id";
            $stmtUpdate = $this->db->prepare($sqlUpdate);
            $stmtUpdate->execute($updateParams);

            // 3. Insertar registro en el historial de movimientos
            $sqlInsert = "INSERT INTO movimientos_inventario (
                producto_id, tipo, referencia_id, cantidad, costo_unitario,
                stock_anterior, stock_posterior, motivo, usuario_id
            ) VALUES (
                :producto_id, :tipo, :referencia_id, :cantidad, :costo_unitario,
                :stock_anterior, :stock_posterior, :motivo, :usuario_id
            )";

            $stmtInsert = $this->db->prepare($sqlInsert);
            $stmtInsert->execute([
                ':producto_id'     => $producto_id,
                ':tipo'            => $tipo,
                ':referencia_id'   => $referencia_id,
                ':cantidad'        => $cantidad,
                ':costo_unitario'  => $costo_unitario > 0 ? $costo_unitario : (float)$producto['precio_compra'],
                ':stock_anterior'  => $stock_anterior,
                ':stock_posterior' => $stock_posterior,
                ':motivo'          => trim($motivo),
                ':usuario_id'      => $usuario_id
            ]);

            $this->db->commit();
            return true;
        } catch (Exception $e) {
            $this->db->rollBack();
            return false;
        }
    }

    /**
     * Obtiene el listado de movimientos para el Kardex o reportes
     */
    public function getHistorial(?string $tipoFiltro = null, ?int $productoId = null, int $limite = 100): array {
        $sql = "
            SELECT m.*, p.nombre as producto_nombre, p.codigo_barras, u.nombre as usuario_nombre
            FROM movimientos_inventario m
            JOIN productos p ON m.producto_id = p.id
            JOIN usuarios u ON m.usuario_id = u.id
            WHERE 1=1
        ";
        $params = [];

        if (!empty($tipoFiltro)) {
            $sql .= " AND m.tipo LIKE :tipo";
            $params[':tipo'] = $tipoFiltro . '%';
        }

        if (!empty($productoId)) {
            $sql .= " AND m.producto_id = :prod_id";
            $params[':prod_id'] = $productoId;
        }

        $sql .= " ORDER BY m.id DESC LIMIT " . (int)$limite;
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }
}
