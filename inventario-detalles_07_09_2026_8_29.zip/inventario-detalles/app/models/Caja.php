<?php
// Modelo de Caja y Arqueo

require_once __DIR__ . '/../config/Database.php';

class Caja {
    private PDO $db;

    public function __construct() {
        $this->db = Database::getConnection();
    }

    /**
     * Obtiene la caja abierta actual del usuario o general
     */
    public function getCajaAbierta(?int $usuario_id = null): ?array {
        $sql = "SELECT c.*, u.nombre as usuario_nombre 
                FROM cajas_sesion c 
                JOIN usuarios u ON c.usuario_id = u.id 
                WHERE c.estado = 'ABIERTA'";
        $params = [];

        if ($usuario_id !== null) {
            $sql .= " AND c.usuario_id = :uid";
            $params[':uid'] = $usuario_id;
        }

        $sql .= " ORDER BY c.id DESC LIMIT 1";
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetch() ?: null;
    }

    public function abrir(int $usuario_id, float $monto_apertura): int {
        // Verificar si ya tiene una abierta
        $abierta = $this->getCajaAbierta($usuario_id);
        if ($abierta) {
            return (int)$abierta['id'];
        }

        $stmt = $this->db->prepare("INSERT INTO cajas_sesion (usuario_id, monto_apertura) VALUES (:uid, :monto)");
        $stmt->execute([
            ':uid'   => $usuario_id,
            ':monto' => $monto_apertura
        ]);
        return (int)$this->db->lastInsertId();
    }

    public function registrarMovimiento(int $caja_id, int $usuario_id, string $tipo, float $monto, string $concepto): bool {
        $stmt = $this->db->prepare("INSERT INTO cajas_movimientos (caja_id, usuario_id, tipo, monto, concepto) VALUES (:cid, :uid, :tipo, :monto, :concepto)");
        return $stmt->execute([
            ':cid'      => $caja_id,
            ':uid'      => $usuario_id,
            ':tipo'     => $tipo,
            ':monto'    => $monto,
            ':concepto' => trim($concepto)
        ]);
    }

    public function getMovimientos(int $caja_id): array {
        $stmt = $this->db->prepare("
            SELECT m.*, u.nombre as usuario_nombre 
            FROM cajas_movimientos m 
            JOIN usuarios u ON m.usuario_id = u.id 
            WHERE m.caja_id = :cid 
            ORDER BY m.id DESC
        ");
        $stmt->execute([':cid' => $caja_id]);
        return $stmt->fetchAll();
    }

    /**
     * Calcula los balances para el arqueo de la caja
     */
    public function getResumen(int $caja_id): array {
        $stmtCaja = $this->db->prepare("SELECT * FROM cajas_sesion WHERE id = :cid");
        $stmtCaja->execute([':cid' => $caja_id]);
        $caja = $stmtCaja->fetch();

        if (!$caja) {
            return [];
        }

        $montoApertura = (float)$caja['monto_apertura'];

        // Movimientos extras (ingresos y gastos menores)
        $stmtMov = $this->db->prepare("
            SELECT 
                SUM(CASE WHEN tipo = 'INGRESO' THEN monto ELSE 0 END) as total_ingresos_extra,
                SUM(CASE WHEN tipo = 'EGRESO_GASTO' THEN monto ELSE 0 END) as total_egresos_gastos
            FROM cajas_movimientos 
            WHERE caja_id = :cid
        ");
        $stmtMov->execute([':cid' => $caja_id]);
        $movimientos = $stmtMov->fetch() ?: ['total_ingresos_extra' => 0, 'total_egresos_gastos' => 0];

        $totalIngresosExtra = (float)($movimientos['total_ingresos_extra'] ?? 0);
        $totalEgresosGastos = (float)($movimientos['total_egresos_gastos'] ?? 0);

        // Ventas por método de pago
        $stmtVentas = $this->db->prepare("
            SELECT metodo_pago, SUM(total) as total_monto, COUNT(id) as total_transacciones
            FROM ventas 
            WHERE caja_id = :cid AND estado = 'COMPLETADA'
            GROUP BY metodo_pago
        ");
        $stmtVentas->execute([':cid' => $caja_id]);
        $ventasPorMetodo = $stmtVentas->fetchAll();

        $ventasEfectivo = 0;
        $ventasDigitales = 0;
        $desgloseVentas = [];

        foreach ($ventasPorMetodo as $v) {
            $metodo = $v['metodo_pago'];
            $monto = (float)$v['total_monto'];
            $desgloseVentas[$metodo] = $monto;

            if ($metodo === 'EFECTIVO') {
                $ventasEfectivo += $monto;
            } else {
                $ventasDigitales += $monto;
            }
        }

        // Efectivo esperado físicamente en el cajón: Base inicial + Ventas efectivo + Entradas manuales - Egresos
        $efectivoEsperado = $montoApertura + $ventasEfectivo + $totalIngresosExtra - $totalEgresosGastos;
        $totalVentasGeneral = $ventasEfectivo + $ventasDigitales;

        return [
            'caja'                 => $caja,
            'monto_apertura'       => $montoApertura,
            'total_ingresos_extra' => $totalIngresosExtra,
            'total_egresos_gastos' => $totalEgresosGastos,
            'ventas_efectivo'      => $ventasEfectivo,
            'ventas_digitales'     => $ventasDigitales,
            'total_ventas'         => $totalVentasGeneral,
            'efectivo_esperado'    => $efectivoEsperado,
            'desglose_ventas'      => $desgloseVentas
        ];
    }

    public function cerrar(int $caja_id, float $monto_cierre_real, ?string $observaciones = null): bool {
        $resumen = $this->getResumen($caja_id);
        if (empty($resumen)) {
            return false;
        }

        $esperado = (float)$resumen['efectivo_esperado'];
        $diferencia = $monto_cierre_real - $esperado;

        $stmt = $this->db->prepare("
            UPDATE cajas_sesion SET 
                monto_cierre_esperado = :esperado,
                monto_cierre_real = :real,
                diferencia = :dif,
                estado = 'CERRADA',
                fecha_cierre = NOW(),
                observaciones = :obs
            WHERE id = :cid
        ");

        return $stmt->execute([
            ':esperado' => $esperado,
            ':real'     => $monto_cierre_real,
            ':dif'      => $diferencia,
            ':obs'      => $observaciones ? trim($observaciones) : null,
            ':cid'      => $caja_id
        ]);
    }

    public function getHistorial(int $limite = 20): array {
        $stmt = $this->db->prepare("
            SELECT c.*, u.nombre as usuario_nombre 
            FROM cajas_sesion c 
            JOIN usuarios u ON c.usuario_id = u.id 
            ORDER BY c.id DESC 
            LIMIT :limite
        ");
        $stmt->bindValue(':limite', $limite, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }
}
