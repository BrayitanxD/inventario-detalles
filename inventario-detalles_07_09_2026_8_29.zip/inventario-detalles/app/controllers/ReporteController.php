<?php
// Controlador de Reportes e Informes

require_once __DIR__ . '/BaseController.php';

class ReporteController extends BaseController {
    public function index(): void {
        requireLogin();

        $reporteModel = new Reporte();

        $fechaInicio = $_GET['fecha_inicio'] ?? date('Y-m-01'); // Primer día del mes actual
        $fechaFin    = $_GET['fecha_fin'] ?? date('Y-m-d');     // Hoy

        $ventasRango         = $reporteModel->getReporteVentasRango($fechaInicio, $fechaFin);
        $inventarioVal       = $reporteModel->getInventarioValorizado();
        $topProductos        = $reporteModel->getTopProductos(10);
        $ventasGrafico       = $reporteModel->getVentasUltimosDias(14);

        // Totales del período seleccionado
        $totalVentasPeriodo = 0;
        $totalCostoPeriodo  = 0;
        $totalGananciaPeriodo = 0;

        foreach ($ventasRango as $v) {
            $totalVentasPeriodo += (float)$v['total'];
            $totalCostoPeriodo  += (float)$v['costo_total_venta'];
            $totalGananciaPeriodo += (float)$v['ganancia_estimada'];
        }

        $this->view('reportes/index', [
            'fechaInicio'          => $fechaInicio,
            'fechaFin'             => $fechaFin,
            'ventasRango'          => $ventasRango,
            'inventarioVal'        => $inventarioVal,
            'topProductos'         => $topProductos,
            'ventasGrafico'        => $ventasGrafico,
            'totalVentasPeriodo'   => $totalVentasPeriodo,
            'totalCostoPeriodo'    => $totalCostoPeriodo,
            'totalGananciaPeriodo' => $totalGananciaPeriodo
        ]);
    }
}
