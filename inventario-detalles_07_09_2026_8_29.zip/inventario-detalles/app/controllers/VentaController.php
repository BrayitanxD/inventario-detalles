<?php
// Controlador del Punto de Venta (POS) y Facturación

require_once __DIR__ . '/BaseController.php';

class VentaController extends BaseController {
    public function pos(): void {
        requireLogin();

        $cajaModel = new Caja();
        $categoriaModel = new Categoria();
        $productoModel = new Producto();

        $cajaActiva = $cajaModel->getCajaAbierta($_SESSION['user']['id']);
        $categorias = $categoriaModel->getAll();
        $productosDestacados = $productoModel->getAll(null, null);

        $this->view('ventas/pos', [
            'cajaActiva'          => $cajaActiva,
            'categorias'          => $categorias,
            'productosDestacados' => array_slice($productosDestacados, 0, 16)
        ]);
    }

    /**
     * Endpoint AJAX llamado por pos.js (Vanilla Fetch) para procesar la venta
     */
    public function guardar(): void {
        requireLogin();

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->json(['success' => false, 'message' => 'Método no permitido.'], 405);
        }

        // Leer datos JSON del cuerpo de la petición
        $jsonInput = file_get_contents('php://input');
        $data = json_decode($jsonInput, true);

        if (!$data || empty($data['items'])) {
            $this->json(['success' => false, 'message' => 'Datos de venta incompletos o vacíos.'], 400);
        }

        // Obtener caja abierta si existe
        $cajaModel = new Caja();
        $cajaActiva = $cajaModel->getCajaAbierta($_SESSION['user']['id']);

        $ventaData = [
            'cliente_nombre'    => $data['cliente_nombre'] ?? 'Consumidor Final',
            'cliente_documento' => $data['cliente_documento'] ?? null,
            'cliente_telefono'  => $data['cliente_telefono'] ?? null,
            'caja_id'           => $cajaActiva['id'] ?? null,
            'usuario_id'        => $_SESSION['user']['id'],
            'metodo_pago'       => $data['metodo_pago'] ?? 'EFECTIVO',
            'subtotal'          => (float)($data['subtotal'] ?? 0),
            'descuento'         => (float)($data['descuento'] ?? 0),
            'total'             => (float)($data['total'] ?? 0),
            'monto_recibido'    => (float)($data['monto_recibido'] ?? 0),
            'cambio'            => (float)($data['cambio'] ?? 0)
        ];

        $items = $data['items'];

        $ventaModel = new Venta();
        $resultado = $ventaModel->procesarVenta($ventaData, $items);

        if ($resultado['success']) {
            $this->json([
                'success'        => true,
                'venta_id'       => $resultado['venta_id'],
                'numero_factura' => $resultado['numero_factura'],
                'url_factura'    => url('venta', 'factura', ['id' => $resultado['venta_id']]),
                'message'        => '¡Venta procesada con éxito!'
            ]);
        } else {
            $this->json([
                'success' => false,
                'message' => $resultado['message']
            ], 422);
        }
    }

    /**
     * Vista de Factura / Ticket térmico POS para imprimir
     */
    public function factura(): void {
        requireLogin();

        $id = (int)($_GET['id'] ?? 0);
        $ventaModel = new Venta();

        $venta = $ventaModel->getById($id);
        if (!$venta) {
            echo "Factura no encontrada.";
            exit;
        }

        $detalles = $ventaModel->getDetalles($id);

        $this->view('ventas/factura', [
            'venta'    => $venta,
            'detalles' => $detalles
        ]);
    }

    /**
     * Historial de ventas con filtros
     */
    public function historial(): void {
        requireLogin();

        $ventaModel = new Venta();
        $filtros = [
            'fecha_inicio' => $_GET['fecha_inicio'] ?? '',
            'fecha_fin'    => $_GET['fecha_fin'] ?? '',
            'metodo_pago'  => $_GET['metodo_pago'] ?? '',
            'busqueda'     => $_GET['q'] ?? ''
        ];

        $ventas = $ventaModel->getVentas($filtros);

        $this->view('ventas/historial', [
            'ventas'  => $ventas,
            'filtros' => $filtros
        ]);
    }

    /**
     * Anulación de venta
     */
    public function anular(): void {
        requireAdmin();

        $id = (int)($_POST['id'] ?? 0);
        $motivo = trim($_POST['motivo'] ?? 'Anulación solicitada por administración');

        if ($id <= 0) {
            setFlash('error', 'ID de factura inválido.');
            $this->redirect('venta', 'historial');
        }

        $ventaModel = new Venta();
        $ok = $ventaModel->anular($id, $motivo, $_SESSION['user']['id']);

        if ($ok) {
            setFlash('success', 'La factura ha sido anulada y el inventario revertido correctamente.');
        } else {
            setFlash('error', 'No se pudo anular la factura o ya se encontraba anulada.');
        }

        $this->redirect('venta', 'historial');
    }
}
