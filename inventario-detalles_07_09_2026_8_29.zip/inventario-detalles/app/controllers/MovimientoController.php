<?php
// Controlador de Movimientos de Inventario (Entradas, Salidas y Kardex)

require_once __DIR__ . '/BaseController.php';

class MovimientoController extends BaseController {
    public function entradas(): void {
        requireLogin();

        $productoModel = new Producto();
        $movModel = new Movimiento();

        $productos = $productoModel->getAll();
        $historialEntradas = $movModel->getHistorial('ENTRADA', null, 50);

        $this->view('movimientos/entradas', [
            'productos' => $productos,
            'historial' => $historialEntradas
        ]);
    }

    public function guardarEntrada(): void {
        requireLogin();

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('movimiento', 'entradas');
        }

        $productoId      = (int)($_POST['producto_id'] ?? 0);
        $cantidad        = (int)($_POST['cantidad'] ?? 0);
        $costoUnitario   = (float)($_POST['costo_unitario'] ?? 0);
        $motivo          = trim($_POST['motivo'] ?? 'Compra de mercancía / Proveedor');
        $actualizarCosto = isset($_POST['actualizar_costo']) && $_POST['actualizar_costo'] == '1';

        if ($productoId <= 0 || $cantidad <= 0) {
            setFlash('error', 'Debes seleccionar un producto y una cantidad válida mayor a cero.');
            $this->redirect('movimiento', 'entradas');
        }

        $movModel = new Movimiento();
        $ok = $movModel->registrar(
            $productoId,
            'ENTRADA_COMPRA',
            $cantidad,
            $costoUnitario,
            $motivo,
            $_SESSION['user']['id'],
            null,
            $actualizarCosto
        );

        if ($ok) {
            setFlash('success', 'Entrada de mercancía registrada exitosamente.');
        } else {
            setFlash('error', 'Error al procesar la entrada de mercancía.');
        }

        $this->redirect('movimiento', 'entradas');
    }

    public function salidas(): void {
        requireLogin();

        $productoModel = new Producto();
        $movModel = new Movimiento();

        $productos = $productoModel->getAll();
        $historialSalidas = $movModel->getHistorial('SALIDA', null, 50);

        $this->view('movimientos/salidas', [
            'productos' => $productos,
            'historial' => $historialSalidas
        ]);
    }

    public function guardarSalida(): void {
        requireLogin();

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('movimiento', 'salidas');
        }

        $productoId = (int)($_POST['producto_id'] ?? 0);
        $cantidad   = (int)($_POST['cantidad'] ?? 0);
        $tipoSalida = $_POST['tipo_salida'] ?? 'SALIDA_MERMA';
        $motivo     = trim($_POST['motivo'] ?? 'Merma o daño de producto');

        if ($productoId <= 0 || $cantidad <= 0) {
            setFlash('error', 'Debes seleccionar un producto y una cantidad válida.');
            $this->redirect('movimiento', 'salidas');
        }

        $movModel = new Movimiento();
        $ok = $movModel->registrar(
            $productoId,
            $tipoSalida,
            $cantidad,
            0,
            $motivo,
            $_SESSION['user']['id']
        );

        if ($ok) {
            setFlash('success', 'Salida de inventario registrada.');
        } else {
            setFlash('error', 'No fue posible registrar la salida. Verifica que haya suficiente stock disponible.');
        }

        $this->redirect('movimiento', 'salidas');
    }

    public function kardex(): void {
        requireLogin();

        $movModel = new Movimiento();
        $productoModel = new Producto();

        $tipo = $_GET['tipo'] ?? null;
        $prodId = !empty($_GET['producto_id']) ? (int)$_GET['producto_id'] : null;

        $movimientos = $movModel->getHistorial($tipo, $prodId, 150);
        $productos = $productoModel->getAll();

        $this->view('movimientos/kardex', [
            'movimientos' => $movimientos,
            'productos'   => $productos,
            'tipoFiltro'  => $tipo,
            'prodFiltro'  => $prodId
        ]);
    }
}
