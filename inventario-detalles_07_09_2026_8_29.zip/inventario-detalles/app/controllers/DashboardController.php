<?php
// Controlador del Dashboard

require_once __DIR__ . '/BaseController.php';

class DashboardController extends BaseController {
    public function index(): void {
        requireLogin();

        $reporteModel   = new Reporte();
        $productoModel  = new Producto();
        $cajaModel      = new Caja();
        $ventaModel     = new Venta();

        $metricas       = $reporteModel->getMetricasDashboard();
        $productosBajos = $productoModel->getBajoStock();
        $cajaActiva     = $cajaModel->getCajaAbierta($_SESSION['user']['id']);
        $ultimasVentas  = $ventaModel->getVentas(['limite' => 5]);
        $topProductos   = $reporteModel->getTopProductos(5);

        $this->view('dashboard/index', [
            'metricas'       => $metricas,
            'productosBajos' => $productosBajos,
            'cajaActiva'     => $cajaActiva,
            'ultimasVentas'  => $ultimasVentas,
            'topProductos'   => $topProductos
        ]);
    }
}
