<?php
// Controlador de Productos y Catálogo

require_once __DIR__ . '/BaseController.php';

class ProductoController extends BaseController {
    public function index(): void {
        requireLogin();

        $productoModel  = new Producto();
        $categoriaModel = new Categoria();

        $categoriaId = isset($_GET['categoria_id']) && $_GET['categoria_id'] !== '' ? (int)$_GET['categoria_id'] : null;
        $busqueda    = $_GET['q'] ?? null;

        $productos    = $productoModel->getAll($categoriaId, $busqueda);
        $categorias   = $categoriaModel->getAll();
        $estadisticas = $productoModel->getEstadisticas();

        $this->view('productos/index', [
            'productos'    => $productos,
            'categorias'   => $categorias,
            'estadisticas' => $estadisticas,
            'categoriaId'  => $categoriaId,
            'busqueda'     => $busqueda
        ]);
    }

    public function guardar(): void {
        requireLogin();

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('producto', 'index');
        }

        $id = !empty($_POST['id']) ? (int)$_POST['id'] : null;

        $data = [
            'codigo_barras' => trim($_POST['codigo_barras'] ?? ''),
            'nombre'        => trim($_POST['nombre'] ?? ''),
            'descripcion'   => trim($_POST['descripcion'] ?? ''),
            'categoria_id'  => (int)($_POST['categoria_id'] ?? 0),
            'precio_compra' => (float)($_POST['precio_compra'] ?? 0),
            'precio_venta'  => (float)($_POST['precio_venta'] ?? 0),
            'stock_actual'  => (int)($_POST['stock_actual'] ?? 0),
            'stock_minimo'  => (int)($_POST['stock_minimo'] ?? 5),
            'ubicacion'     => trim($_POST['ubicacion'] ?? ''),
            'imagen'        => null
        ];

        // Procesar subida de imagen si existe
        if (!empty($_FILES['imagen']['name']) && $_FILES['imagen']['error'] === UPLOAD_ERR_OK) {
            $ext = strtolower(pathinfo($_FILES['imagen']['name'], PATHINFO_EXTENSION));
            $permitidas = ['jpg', 'jpeg', 'png', 'webp'];
            if (in_array($ext, $permitidas)) {
                $nombreArchivo = 'prod_' . time() . '_' . rand(100, 999) . '.' . $ext;
                $destino = __DIR__ . '/../../public/img/productos/' . $nombreArchivo;
                if (move_uploaded_file($_FILES['imagen']['tmp_name'], $destino)) {
                    $data['imagen'] = 'img/productos/' . $nombreArchivo;
                }
            }
        }

        $productoModel = new Producto();

        if ($id) {
            $productoModel->actualizar($id, $data);
            setFlash('success', 'Producto actualizado correctamente.');
        } else {
            $nuevoId = $productoModel->crear($data);
            if ($nuevoId && $data['stock_actual'] > 0) {
                // Registrar entrada inicial en Kardex
                $movModel = new Movimiento();
                $movModel->registrar(
                    $nuevoId,
                    'ENTRADA_AJUSTE',
                    $data['stock_actual'],
                    $data['precio_compra'],
                    'Inventario inicial al crear producto',
                    $_SESSION['user']['id']
                );
            }
            setFlash('success', 'Producto creado exitosamente.');
        }

        $this->redirect('producto', 'index');
    }

    public function eliminar(): void {
        requireAdmin();

        $id = (int)($_POST['id'] ?? $_GET['id'] ?? 0);
        if ($id > 0) {
            $productoModel = new Producto();
            $productoModel->eliminar($id);
            setFlash('success', 'Producto eliminado con éxito.');
        }

        $this->redirect('producto', 'index');
    }

    /**
     * Endpoint AJAX para búsqueda interactiva en POS
     */
    public function buscarAjax(): void {
        requireLogin();
        $term = trim($_GET['term'] ?? '');
        $productoModel = new Producto();
        $resultados = $productoModel->searchLive($term);
        $this->json($resultados);
    }

    /**
     * Endpoint AJAX para escaneo con lector de código de barras
     */
    public function barcodeAjax(): void {
        requireLogin();
        $code = trim($_GET['code'] ?? '');
        $productoModel = new Producto();
        $producto = $productoModel->getByBarcode($code);
        if ($producto) {
            $this->json(['success' => true, 'producto' => $producto]);
        } else {
            $this->json(['success' => false, 'message' => 'Código de barras no encontrado.']);
        }
    }
}
