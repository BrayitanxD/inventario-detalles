<?php
// Controlador de Categorías

require_once __DIR__ . '/BaseController.php';

class CategoriaController extends BaseController {
    public function index(): void {
        requireLogin();

        $categoriaModel = new Categoria();
        $categorias = $categoriaModel->getAll();

        $this->view('categorias/index', [
            'categorias' => $categorias
        ]);
    }

    public function guardar(): void {
        requireLogin();

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('categoria', 'index');
        }

        $id = !empty($_POST['id']) ? (int)$_POST['id'] : null;
        $nombre = trim($_POST['nombre'] ?? '');
        $descripcion = trim($_POST['descripcion'] ?? '');

        if (empty($nombre)) {
            setFlash('error', 'El nombre de la categoría es obligatorio.');
            $this->redirect('categoria', 'index');
        }

        $categoriaModel = new Categoria();

        if ($id) {
            $categoriaModel->actualizar($id, $nombre, $descripcion);
            setFlash('success', 'Categoría actualizada.');
        } else {
            $categoriaModel->crear($nombre, $descripcion);
            setFlash('success', 'Categoría creada con éxito.');
        }

        $this->redirect('categoria', 'index');
    }

    public function eliminar(): void {
        requireAdmin();

        $id = (int)($_POST['id'] ?? $_GET['id'] ?? 0);
        if ($id > 0) {
            $categoriaModel = new Categoria();
            $categoriaModel->eliminar($id);
            setFlash('success', 'Categoría eliminada.');
        }

        $this->redirect('categoria', 'index');
    }
}
