<?php
// Controlador de Caja, Turnos y Arqueo

require_once __DIR__ . '/BaseController.php';

class CajaController extends BaseController {
    public function arqueo(): void {
        requireLogin();

        $cajaModel = new Caja();
        $cajaActiva = $cajaModel->getCajaAbierta($_SESSION['user']['id']);

        $resumen = [];
        $movimientos = [];

        if ($cajaActiva) {
            $resumen = $cajaModel->getResumen((int)$cajaActiva['id']);
            $movimientos = $cajaModel->getMovimientos((int)$cajaActiva['id']);
        }

        $historialCierres = $cajaModel->getHistorial(10);

        $this->view('caja/arqueo', [
            'cajaActiva'       => $cajaActiva,
            'resumen'          => $resumen,
            'movimientos'      => $movimientos,
            'historialCierres' => $historialCierres
        ]);
    }

    public function abrir(): void {
        requireLogin();

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('caja', 'arqueo');
        }

        $monto = (float)($_POST['monto_apertura'] ?? 0);
        $cajaModel = new Caja();
        $cajaModel->abrir($_SESSION['user']['id'], $monto);

        setFlash('success', 'Caja abierta con una base de ' . formatPrice($monto));
        $this->redirect('caja', 'arqueo');
    }

    public function cerrar(): void {
        requireLogin();

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('caja', 'arqueo');
        }

        $cajaId = (int)($_POST['caja_id'] ?? 0);
        $montoReal = (float)($_POST['monto_cierre_real'] ?? 0);
        $observaciones = trim($_POST['observaciones'] ?? '');

        $cajaModel = new Caja();
        $ok = $cajaModel->cerrar($cajaId, $montoReal, $observaciones);

        if ($ok) {
            setFlash('success', 'Turno y arqueo de caja cerrado correctamente.');
        } else {
            setFlash('error', 'Error al cerrar la caja.');
        }

        $this->redirect('caja', 'arqueo');
    }

    public function movimiento(): void {
        requireLogin();

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('caja', 'arqueo');
        }

        $cajaId   = (int)($_POST['caja_id'] ?? 0);
        $tipo     = $_POST['tipo'] ?? 'EGRESO_GASTO';
        $monto    = (float)($_POST['monto'] ?? 0);
        $concepto = trim($_POST['concepto'] ?? '');

        if ($cajaId <= 0 || $monto <= 0 || empty($concepto)) {
            setFlash('error', 'Por favor ingresa un monto y concepto válido.');
            $this->redirect('caja', 'arqueo');
        }

        $cajaModel = new Caja();
        $cajaModel->registrarMovimiento($cajaId, $_SESSION['user']['id'], $tipo, $monto, $concepto);

        setFlash('success', 'Movimiento de caja registrado exitosamente.');
        $this->redirect('caja', 'arqueo');
    }
}
