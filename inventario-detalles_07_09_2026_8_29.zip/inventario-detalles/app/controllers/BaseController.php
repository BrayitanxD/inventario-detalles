<?php
// Controlador Base del cual heredan todos los controladores

class BaseController {
    /**
     * Renderiza una vista pasando variables
     * @param string $view Ruta relativa dentro de app/views/ (ej: 'productos/index')
     * @param array $data Variables que estarán disponibles en la vista
     */
    protected function view(string $view, array $data = []): void {
        extract($data);
        $viewFile = __DIR__ . '/../views/' . $view . '.php';

        if (file_exists($viewFile)) {
            require_once $viewFile;
        } else {
            echo "Error: La vista '{$view}' no existe en {$viewFile}";
        }
    }

    /**
     * Respuesta JSON para peticiones AJAX con Fetch API
     */
    protected function json(array $data, int $status = 200): void {
        jsonResponse($data, $status);
    }

    /**
     * Redirección a una ruta del sistema
     */
    protected function redirect(string $controller, string $action = 'index', array $params = []): void {
        header('Location: ' . url($controller, $action, $params));
        exit;
    }
}
