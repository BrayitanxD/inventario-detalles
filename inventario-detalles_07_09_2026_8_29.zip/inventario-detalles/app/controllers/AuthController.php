<?php
// Controlador de Autenticación

require_once __DIR__ . '/BaseController.php';

class AuthController extends BaseController {
    public function login(): void {
        if (isLoggedIn()) {
            $this->redirect('dashboard', 'index');
        }

        $error = null;

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $usuario = trim($_POST['usuario'] ?? '');
            $password = trim($_POST['password'] ?? '');

            if (!empty($usuario) && !empty($password)) {
                $userModel = new Usuario();
                $user = $userModel->autenticar($usuario, $password);

                if ($user) {
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['user']    = [
                        'id'      => $user['id'],
                        'nombre'  => $user['nombre'],
                        'usuario' => $user['usuario'],
                        'rol'     => $user['rol']
                    ];
                    setFlash('success', '¡Bienvenido(a), ' . htmlspecialchars($user['nombre']) . '!');
                    $this->redirect('dashboard', 'index');
                } else {
                    $error = 'Usuario o contraseña incorrectos.';
                }
            } else {
                $error = 'Por favor completa todos los campos.';
            }
        }

        $this->view('auth/login', ['error' => $error]);
    }

    public function logout(): void {
        session_unset();
        session_destroy();
        session_start();
        setFlash('info', 'Has cerrado sesión correctamente.');
        $this->redirect('auth', 'login');
    }
}
