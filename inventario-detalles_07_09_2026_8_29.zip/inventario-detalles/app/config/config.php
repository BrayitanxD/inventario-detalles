<?php
// Configuración Global de la Aplicación

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Zona Horaria (Colombia / Perú / Ecuador / México - UTC-5)
date_default_timezone_set('America/Bogota');

// Constantes de Base de Datos
define('DB_HOST', '127.0.0.1');
define('DB_PORT', '3306');
define('DB_NAME', 'inventario_detalles');
define('DB_USER', 'root');
define('DB_PASS', '');

// Nombre y datos del comercio
define('APP_NAME', 'Peluches & Detalles POS');
define('BUSINESS_NAME', 'Tienda Peluches, Detalles & Decoraciones');
define('BUSINESS_NIT', '900.123.456-7');
define('BUSINESS_PHONE', '(+57) 300 123 4567');
define('BUSINESS_ADDRESS', 'Calle 10 # 5-20, Centro');
define('BUSINESS_CITY', 'Colombia');

// Detección dinámica de BASE_URL
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || ($_SERVER['SERVER_PORT'] ?? 80) == 443) ? "https://" : "http://";
$host = $_SERVER['HTTP_HOST'] ?? 'localhost';
$scriptDir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? ''));
$baseUrl = rtrim($protocol . $host . $scriptDir, '/');

// Asegurarse de apuntar a la carpeta public
if (!str_ends_with($baseUrl, '/public')) {
    $baseUrl = rtrim($baseUrl, '/') . '/public';
}
define('BASE_URL', $baseUrl);

/**
 * Genera URLs internas para el sistema con soporte robusto
 * Ejemplo: url('producto', 'index') => http://localhost/inventario-detalles/public/index.php?c=producto&a=index
 */
function url(string $controller = 'dashboard', string $action = 'index', array $params = []): string {
    $queryString = http_build_query(array_merge([
        'c' => $controller,
        'a' => $action
    ], $params));
    return BASE_URL . '/index.php?' . $queryString;
}

/**
 * Genera URLs para recursos estáticos (CSS, JS, imágenes)
 */
function asset(string $path): string {
    return BASE_URL . '/' . ltrim($path, '/');
}

/**
 * Formato de moneda para precios (ej: $ 85.000)
 */
function formatPrice($amount): string {
    return '$ ' . number_format((float)$amount, 0, ',', '.');
}

/**
 * Verifica si hay una sesión activa
 */
function isLoggedIn(): bool {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

/**
 * Retorna datos del usuario actual
 */
function currentUser(): ?array {
    return $_SESSION['user'] ?? null;
}

/**
 * Obliga inicio de sesión para acceder
 */
function requireLogin(): void {
    if (!isLoggedIn()) {
        header('Location: ' . url('auth', 'login'));
        exit;
    }
}

/**
 * Requiere rol de administrador
 */
function requireAdmin(): void {
    requireLogin();
    if (($_SESSION['user']['rol'] ?? '') !== 'admin') {
        $_SESSION['flash_error'] = 'No tienes permisos de administrador para realizar esta acción.';
        header('Location: ' . url('dashboard', 'index'));
        exit;
    }
}

/**
 * Respuesta JSON limpia para llamadas AJAX (Vanilla Fetch)
 */
function jsonResponse(array $data, int $status = 200): void {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

/**
 * Helper para mensajes flash en sesión
 */
function setFlash(string $type, string $message): void {
    $_SESSION['flash_' . $type] = $message;
}

function getFlash(string $type): ?string {
    if (isset($_SESSION['flash_' . $type])) {
        $msg = $_SESSION['flash_' . $type];
        unset($_SESSION['flash_' . $type]);
        return $msg;
    }
    return null;
}
