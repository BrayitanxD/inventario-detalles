<?php
// Script para ejecutar la migración SQL en MySQL de XAMPP
try {
    $pdo = new PDO('mysql:host=127.0.0.1;port=3306', 'root', '', [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
    ]);

    $sql = file_get_contents(__DIR__ . '/inventario_detalles.sql');
    
    // Ejecutar múltiples sentencias
    $pdo->exec($sql);
    echo "SUCCESS: Base de datos y tablas creadas exitosamente con datos semilla.\n";
} catch (PDOException $e) {
    echo "ERROR: " . $e->getMessage() . "\n";
}
