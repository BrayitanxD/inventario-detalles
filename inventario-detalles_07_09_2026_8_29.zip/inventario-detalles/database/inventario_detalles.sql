-- =======================================================
-- Base de Datos: inventario_detalles
-- Sistema de Inventario, POS y Facturación
-- Especialidad: Peluches, Detalles, Regalos y Decoraciones
-- =======================================================

CREATE DATABASE IF NOT EXISTS `inventario_detalles` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `inventario_detalles`;

-- 1. Tabla de Usuarios
CREATE TABLE IF NOT EXISTS `usuarios` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `nombre` VARCHAR(100) NOT NULL,
  `usuario` VARCHAR(50) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL,
  `rol` ENUM('admin', 'vendedor') NOT NULL DEFAULT 'vendedor',
  `estado` TINYINT(1) NOT NULL DEFAULT 1,
  `creado_en` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. Tabla de Categorías
CREATE TABLE IF NOT EXISTS `categorias` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `nombre` VARCHAR(100) NOT NULL,
  `descripcion` TEXT NULL,
  `estado` TINYINT(1) NOT NULL DEFAULT 1,
  `creado_en` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. Tabla de Productos
CREATE TABLE IF NOT EXISTS `productos` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `codigo_barras` VARCHAR(50) UNIQUE NULL,
  `nombre` VARCHAR(150) NOT NULL,
  `descripcion` TEXT NULL,
  `categoria_id` INT NOT NULL,
  `precio_compra` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `precio_venta` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `stock_actual` INT NOT NULL DEFAULT 0,
  `stock_minimo` INT NOT NULL DEFAULT 5,
  `ubicacion` VARCHAR(100) NULL,
  `imagen` VARCHAR(255) NULL,
  `es_combo` TINYINT(1) NOT NULL DEFAULT 0,
  `estado` TINYINT(1) NOT NULL DEFAULT 1,
  `creado_en` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_prod_categoria` FOREIGN KEY (`categoria_id`) REFERENCES `categorias` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. Tabla de Combos / Arreglos (Componentes de una ancheta/arreglo)
CREATE TABLE IF NOT EXISTS `combos_detalle` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `combo_id` INT NOT NULL,
  `insumo_id` INT NOT NULL,
  `cantidad` INT NOT NULL DEFAULT 1,
  CONSTRAINT `fk_combo_padre` FOREIGN KEY (`combo_id`) REFERENCES `productos` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_combo_insumo` FOREIGN KEY (`insumo_id`) REFERENCES `productos` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 5. Tabla de Cajas (Sesiones de Turno / Arqueos)
CREATE TABLE IF NOT EXISTS `cajas_sesion` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `usuario_id` INT NOT NULL,
  `monto_apertura` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `monto_cierre_esperado` DECIMAL(12,2) NULL,
  `monto_cierre_real` DECIMAL(12,2) NULL,
  `diferencia` DECIMAL(12,2) NULL,
  `estado` ENUM('ABIERTA', 'CERRADA') NOT NULL DEFAULT 'ABIERTA',
  `fecha_apertura` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `fecha_cierre` DATETIME NULL,
  `observaciones` TEXT NULL,
  CONSTRAINT `fk_caja_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 6. Movimientos de Efectivo en Caja (Ingresos y Egresos / Gastos Menores)
CREATE TABLE IF NOT EXISTS `cajas_movimientos` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `caja_id` INT NOT NULL,
  `usuario_id` INT NOT NULL,
  `tipo` ENUM('INGRESO', 'EGRESO_GASTO') NOT NULL,
  `monto` DECIMAL(12,2) NOT NULL,
  `concepto` VARCHAR(255) NOT NULL,
  `fecha` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_mov_caja` FOREIGN KEY (`caja_id`) REFERENCES `cajas_sesion` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_mov_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 7. Tabla de Ventas (Facturas / Comprobantes POS)
CREATE TABLE IF NOT EXISTS `ventas` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `numero_factura` VARCHAR(50) NOT NULL UNIQUE,
  `cliente_nombre` VARCHAR(150) NOT NULL DEFAULT 'Consumidor Final',
  `cliente_documento` VARCHAR(50) NULL,
  `cliente_telefono` VARCHAR(50) NULL,
  `caja_id` INT NULL,
  `usuario_id` INT NOT NULL,
  `metodo_pago` ENUM('EFECTIVO', 'NEQUI', 'DAVIPLATA', 'TARJETA', 'TRANSFERENCIA') NOT NULL DEFAULT 'EFECTIVO',
  `subtotal` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `descuento` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `total` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `monto_recibido` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `cambio` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `estado` ENUM('COMPLETADA', 'ANULADA') NOT NULL DEFAULT 'COMPLETADA',
  `fecha` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_venta_caja` FOREIGN KEY (`caja_id`) REFERENCES `cajas_sesion` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_venta_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 8. Detalle de Ventas
CREATE TABLE IF NOT EXISTS `ventas_detalle` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `venta_id` INT NOT NULL,
  `producto_id` INT NOT NULL,
  `cantidad` INT NOT NULL,
  `precio_unitario` DECIMAL(12,2) NOT NULL,
  `costo_unitario` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `subtotal` DECIMAL(12,2) NOT NULL,
  CONSTRAINT `fk_det_venta` FOREIGN KEY (`venta_id`) REFERENCES `ventas` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_det_producto` FOREIGN KEY (`producto_id`) REFERENCES `productos` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 9. Movimientos de Inventario (Kardex: Entradas y Salidas)
CREATE TABLE IF NOT EXISTS `movimientos_inventario` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `producto_id` INT NOT NULL,
  `tipo` ENUM('ENTRADA_COMPRA', 'ENTRADA_AJUSTE', 'SALIDA_VENTA', 'SALIDA_MERMA', 'SALIDA_USO_INTERNO') NOT NULL,
  `referencia_id` INT NULL,
  `cantidad` INT NOT NULL,
  `costo_unitario` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `stock_anterior` INT NOT NULL,
  `stock_posterior` INT NOT NULL,
  `motivo` VARCHAR(255) NULL,
  `usuario_id` INT NOT NULL,
  `fecha` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_kardex_prod` FOREIGN KEY (`producto_id`) REFERENCES `productos` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_kardex_user` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =======================================================
-- DATOS SEMILLA / INICIALES
-- =======================================================

-- Usuarios (password: admin123)
INSERT INTO `usuarios` (`id`, `nombre`, `usuario`, `password`, `rol`, `estado`) VALUES
(1, 'Administrador General', 'admin', '$2y$10$1QqB537Ox63TNxa.66fg6enIVON/04XkXQ52xUqlPnMtxWCU82zK2', 'admin', 1),
(2, 'Vendedor Principal', 'vendedor', '$2y$10$1QqB537Ox63TNxa.66fg6enIVON/04XkXQ52xUqlPnMtxWCU82zK2', 'vendedor', 1)
ON DUPLICATE KEY UPDATE `id`=`id`;

-- Categorías
INSERT INTO `categorias` (`id`, `nombre`, `descripcion`) VALUES
(1, 'Peluches', 'Peluches gigantes, medianos, de personajes y llaveros'),
(2, 'Globos y Helio', 'Globos metalizados, látex, números gigantes, helio y varillas'),
(3, 'Chocolatería y Dulces', 'Chocolates Ferrero, barras, bombones y confitería'),
(4, 'Cajas y Empaques', 'Cajas de madera, acetato, cartón decorativo, papel seda y lazos'),
(5, 'Decoración y Fiestas', 'Guirnaldas, luces LED, velas de cumpleaños y letreros'),
(6, 'Anchetas y Arreglos', 'Arreglos listos para regalo con combinación de productos')
ON DUPLICATE KEY UPDATE `id`=`id`;

-- Productos Iniciales de Ejemplo
INSERT INTO `productos` (`id`, `codigo_barras`, `nombre`, `descripcion`, `categoria_id`, `precio_compra`, `precio_venta`, `stock_actual`, `stock_minimo`, `ubicacion`) VALUES
(1, '7701001', 'Oso de Peluche Gigante 1 Metro Crema', 'Peluche extra suave con moño de satín', 1, 45000.00, 85000.00, 8, 3, 'Estante A1'),
(2, '7701002', 'Peluche Stitch 40cm', 'Peluche azul Stitch bordado antialérgico', 1, 20000.00, 42000.00, 15, 4, 'Estante A2'),
(3, '7701003', 'Peluche Panda con Corazón 30cm', 'Oso panda abrazando corazón te amo', 1, 15000.00, 32000.00, 12, 3, 'Estante A3'),
(4, '7702001', 'Globo Metalizado Corazón Rojo 18"', 'Globo para helio o aire forma corazón', 2, 1200.00, 4000.00, 50, 15, 'Cajón Globos G1'),
(5, '7702002', 'Bouquet de Globos Feliz Cumpleaños', 'Set de 5 globos temáticos surtidos', 2, 6000.00, 16000.00, 20, 5, 'Cajón Globos G2'),
(6, '7703001', 'Chocolates Ferrero Rocher x 8', 'Caja dorada con 8 bombones de avellana', 3, 14000.00, 22000.00, 25, 6, 'Nevera Mostrador'),
(7, '7703002', 'Nutella B-ready x 6', 'Galletas rellenas de avellana', 3, 9000.00, 16000.00, 18, 5, 'Vitrina Dulces'),
(8, '7704001', 'Caja de Madera Decorativa Vintage 25x25', 'Caja base para ancheta rústica barnizada', 4, 11000.00, 22000.00, 30, 8, 'Bodega Empaques B1'),
(9, '7705001', 'Luces LED Guirnalda Cálida 3 Metros', 'Luces a pila para decoración de regalos', 5, 4500.00, 12000.00, 35, 10, 'Mostrador Accesorios')
ON DUPLICATE KEY UPDATE `id`=`id`;
