// Funciones Globales JS (Vanilla ES6, sin jQuery)

function formatMoney(amount) {
    return '$ ' + new Intl.NumberFormat('es-CO', {
        minimumFractionDigits: 0,
        maximumFractionDigits: 0
    }).format(amount);
}

// Confirmar acciones de eliminación o anulación con SweetAlert2
function confirmarAccion(event, titulo, texto) {
    event.preventDefault();
    const form = event.target.closest('form');
    
    Swal.fire({
        title: titulo || '¿Estás seguro?',
        text: texto || 'Esta acción no se puede deshacer.',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#e11d48',
        cancelButtonColor: '#64748b',
        confirmButtonText: 'Sí, continuar',
        cancelButtonText: 'Cancelar'
    }).then((result) => {
        if (result.isConfirmed) {
            form.submit();
        }
    });
}
