// Lógica del Punto de Venta (POS) - JavaScript Moderno (Vanilla ES6, sin jQuery)

let cart = [];
let discount = 0;
let paymentMethod = 'EFECTIVO';

document.addEventListener('DOMContentLoaded', () => {
    initSearch();
    initBarcodeScanner();
    initPaymentListeners();
    renderCart();
});

// Búsqueda en vivo con Debounce
function initSearch() {
    const searchInput = document.getElementById('posSearchInput');
    if (!searchInput) return;

    let debounceTimer;
    searchInput.addEventListener('input', (e) => {
        clearTimeout(debounceTimer);
        const query = e.target.value.trim();

        debounceTimer = setTimeout(() => {
            if (query.length >= 2) {
                fetchProducts(query);
            } else if (query.length === 0) {
                // Restaurar catálogo general
                location.reload();
            }
        }, 300);
    });
}

// Escáner de Código de Barras
function initBarcodeScanner() {
    const barcodeInput = document.getElementById('posBarcodeInput');
    if (!barcodeInput) return;

    barcodeInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            const code = barcodeInput.value.trim();
            if (code) {
                scanBarcode(code);
                barcodeInput.value = '';
            }
        }
    });
}

async function scanBarcode(code) {
    try {
        const res = await fetch(`index.php?c=producto&a=barcodeAjax&code=${encodeURIComponent(code)}`);
        const data = await res.json();

        if (data.success && data.producto) {
            addToCart(data.producto);
        } else {
            Swal.fire({
                icon: 'warning',
                title: 'No encontrado',
                text: `No existe producto con código: ${code}`,
                timer: 2000,
                showConfirmButton: false,
                toast: true,
                position: 'top-end'
            });
        }
    } catch (err) {
        console.error('Error al escanear código:', err);
    }
}

async function fetchProducts(term) {
    try {
        const res = await fetch(`index.php?c=producto&a=buscarAjax&term=${encodeURIComponent(term)}`);
        const products = await res.json();
        renderProductsGrid(products);
    } catch (err) {
        console.error('Error al buscar productos:', err);
    }
}

function renderProductsGrid(products) {
    const container = document.getElementById('posProductsGrid');
    if (!container) return;

    if (products.length === 0) {
        container.innerHTML = `
            <div class="col-12 text-center py-5">
                <i class="bi bi-search text-muted fs-1 mb-2"></i>
                <h6 class="text-muted">No se encontraron productos coincidentes</h6>
            </div>
        `;
        return;
    }

    container.innerHTML = products.map(p => {
        const stockClass = p.stock_actual <= p.stock_minimo ? 'badge bg-danger' : 'badge bg-success';
        const imgUrl = p.imagen ? p.imagen : 'https://placehold.co/200x150/fdf2f8/ec4899?text=Detalle';
        
        return `
            <div class="col-6 col-md-4 col-xl-3 mb-3">
                <div class="card h-100 pos-product-card shadow-sm" onclick='addToCart(${JSON.stringify(p)})'>
                    <img src="${imgUrl}" class="card-img-top pos-product-img" alt="${p.nombre}">
                    <div class="card-body p-2 d-flex flex-column">
                        <span class="badge bg-light text-secondary small text-truncate mb-1">${p.categoria_nombre || 'General'}</span>
                        <h6 class="card-title fs-6 fw-bold mb-1 text-truncate" title="${p.nombre}">${p.nombre}</h6>
                        <div class="mt-auto d-flex justify-content-between align-items-center pt-2">
                            <span class="text-primary fw-bold">${formatMoney(p.precio_venta)}</span>
                            <span class="${stockClass} extra-small">Stock: ${p.stock_actual}</span>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }).join('');
}

// Agregar al carrito
function addToCart(product) {
    const existingIndex = cart.findIndex(item => item.id === parseInt(product.id));

    if (existingIndex !== -1) {
        if (cart[existingIndex].cantidad + 1 > product.stock_actual) {
            Swal.fire({
                icon: 'warning',
                title: 'Stock Límite',
                text: `Solo hay ${product.stock_actual} unidades disponibles de este producto.`,
                toast: true,
                position: 'top-end',
                timer: 2500,
                showConfirmButton: false
            });
            return;
        }
        cart[existingIndex].cantidad += 1;
    } else {
        if (product.stock_actual <= 0) {
            Swal.fire({
                icon: 'error',
                title: 'Sin Stock',
                text: 'Este producto no tiene existencias disponibles.',
                toast: true,
                position: 'top-end',
                timer: 2500,
                showConfirmButton: false
            });
            return;
        }

        cart.push({
            id: parseInt(product.id),
            nombre: product.nombre,
            precio: parseFloat(product.precio_venta),
            stock_actual: parseInt(product.stock_actual),
            cantidad: 1
        });
    }

    renderCart();
}

function updateQuantity(id, delta) {
    const item = cart.find(i => i.id === id);
    if (!item) return;

    const newQty = item.cantidad + delta;
    if (newQty <= 0) {
        removeFromCart(id);
        return;
    }

    if (newQty > item.stock_actual) {
        Swal.fire({
            icon: 'warning',
            title: 'Stock Límite',
            text: `No puedes superar las ${item.stock_actual} unidades en inventario.`,
            toast: true,
            position: 'top-end',
            timer: 2000,
            showConfirmButton: false
        });
        return;
    }

    item.cantidad = newQty;
    renderCart();
}

function setQuantityDirect(id, qty) {
    const item = cart.find(i => i.id === id);
    if (!item) return;

    let val = parseInt(qty);
    if (isNaN(val) || val <= 0) {
        removeFromCart(id);
        return;
    }

    if (val > item.stock_actual) {
        val = item.stock_actual;
    }

    item.cantidad = val;
    renderCart();
}

function removeFromCart(id) {
    cart = cart.filter(item => item.id !== id);
    renderCart();
}

function clearCart() {
    if (cart.length === 0) return;
    cart = [];
    discount = 0;
    renderCart();
}

// Renderizar lista del carrito y totales
function renderCart() {
    const container = document.getElementById('posCartItemsContainer');
    const badgeCount = document.getElementById('cartTotalItemsBadge');
    if (!container) return;

    if (cart.length === 0) {
        container.innerHTML = `
            <div class="text-center py-5 text-muted">
                <i class="bi bi-cart3 fs-1 opacity-50 mb-2"></i>
                <p class="mb-0 small">El carrito está vacío</p>
                <small class="text-secondary">Selecciona productos del catálogo o usa el lector de código</small>
            </div>
        `;
        if (badgeCount) badgeCount.innerText = '0';
        updateTotals(0);
        return;
    }

    let subtotal = 0;
    let totalItems = 0;

    container.innerHTML = cart.map(item => {
        const itemTotal = item.cantidad * item.precio;
        subtotal += itemTotal;
        totalItems += item.cantidad;

        return `
            <div class="p-2 border-bottom d-flex align-items-center justify-content-between gap-2">
                <div class="flex-grow-1 overflow-hidden">
                    <h6 class="mb-0 text-truncate small fw-bold">${item.nombre}</h6>
                    <small class="text-muted">${formatMoney(item.precio)} c/u</small>
                </div>
                <div class="d-flex align-items-center gap-1">
                    <button class="btn btn-outline-secondary btn-sm px-2 py-0" onclick="updateQuantity(${item.id}, -1)">-</button>
                    <input type="number" class="form-control form-control-sm text-center px-1 py-0" style="width: 45px;" 
                           value="${item.cantidad}" min="1" max="${item.stock_actual}" onchange="setQuantityDirect(${item.id}, this.value)">
                    <button class="btn btn-outline-secondary btn-sm px-2 py-0" onclick="updateQuantity(${item.id}, 1)">+</button>
                </div>
                <div class="text-end" style="min-width: 75px;">
                    <div class="fw-bold small text-primary">${formatMoney(itemTotal)}</div>
                    <button class="btn btn-link text-danger p-0 extra-small" onclick="removeFromCart(${item.id})">
                        <i class="bi bi-trash"></i>
                    </button>
                </div>
            </div>
        `;
    }).join('');

    if (badgeCount) badgeCount.innerText = totalItems;
    updateTotals(subtotal);
}

function updateTotals(subtotal) {
    const subtotalEl = document.getElementById('posSubtotalText');
    const discountEl = document.getElementById('posDiscountInput');
    const totalEl = document.getElementById('posTotalText');
    const receivedEl = document.getElementById('posAmountReceived');
    const changeEl = document.getElementById('posChangeText');
    const submitBtn = document.getElementById('btnCompletarVenta');

    if (discountEl) {
        discount = parseFloat(discountEl.value) || 0;
    }

    const total = Math.max(0, subtotal - discount);

    if (subtotalEl) subtotalEl.innerText = formatMoney(subtotal);
    if (totalEl) totalEl.innerText = formatMoney(total);

    if (receivedEl) {
        const received = parseFloat(receivedEl.value) || 0;
        const change = Math.max(0, received - total);
        if (changeEl) changeEl.innerText = formatMoney(change);

        if (submitBtn) {
            if (cart.length === 0) {
                submitBtn.disabled = true;
            } else if (paymentMethod === 'EFECTIVO' && received < total) {
                submitBtn.disabled = true;
            } else {
                submitBtn.disabled = false;
            }
        }
    }
}

function initPaymentListeners() {
    const methodSelect = document.getElementById('posPaymentMethod');
    const receivedInput = document.getElementById('posAmountReceived');
    const discountInput = document.getElementById('posDiscountInput');
    const cashContainer = document.getElementById('cashCalculationContainer');

    if (methodSelect) {
        methodSelect.addEventListener('change', (e) => {
            paymentMethod = e.target.value;
            if (cashContainer) {
                if (paymentMethod === 'EFECTIVO') {
                    cashContainer.classList.remove('d-none');
                } else {
                    cashContainer.classList.add('d-none');
                    // En medios electrónicos, el monto recibido es exactamente el total
                    if (receivedInput) {
                        const totalText = document.getElementById('posTotalText').innerText;
                        const numericTotal = parseFloat(totalText.replace(/[^0-9]/g, '')) || 0;
                        receivedInput.value = numericTotal;
                    }
                }
            }
            renderCart();
        });
    }

    if (receivedInput) {
        receivedInput.addEventListener('input', () => {
            renderCart();
        });
    }

    if (discountInput) {
        discountInput.addEventListener('input', () => {
            renderCart();
        });
    }
}

// Completar la Venta y Enviar al Backend vía Fetch API
async function submitSale() {
    if (cart.length === 0) return;

    const clienteNombre = document.getElementById('posClienteNombre')?.value.trim() || 'Consumidor Final';
    const clienteDoc = document.getElementById('posClienteDoc')?.value.trim() || '';
    const clienteTel = document.getElementById('posClienteTel')?.value.trim() || '';
    const subtotalText = document.getElementById('posSubtotalText')?.innerText || '0';
    const subtotal = parseFloat(subtotalText.replace(/[^0-9]/g, '')) || 0;
    const totalText = document.getElementById('posTotalText')?.innerText || '0';
    const total = parseFloat(totalText.replace(/[^0-9]/g, '')) || 0;
    const receivedInput = document.getElementById('posAmountReceived');
    const montoRecibido = paymentMethod === 'EFECTIVO' ? (parseFloat(receivedInput?.value) || total) : total;
    const cambio = Math.max(0, montoRecibido - total);

    const payload = {
        cliente_nombre: clienteNombre,
        cliente_documento: clienteDoc,
        cliente_telefono: clienteTel,
        metodo_pago: paymentMethod,
        subtotal: subtotal,
        descuento: discount,
        total: total,
        monto_recibido: montoRecibido,
        cambio: cambio,
        items: cart.map(item => ({
            id: item.id,
            cantidad: item.cantidad,
            precio: item.precio
        }))
    };

    const submitBtn = document.getElementById('btnCompletarVenta');
    if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Procesando...';
    }

    try {
        const res = await fetch('index.php?c=venta&a=guardar', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            },
            body: JSON.stringify(payload)
        });

        const data = await res.json();

        if (data.success) {
            Swal.fire({
                icon: 'success',
                title: '¡Venta Realizada con Éxito!',
                html: `
                    <p class="mb-2">Factura: <strong>${data.numero_factura}</strong></p>
                    <p class="mb-3 text-muted">Total: ${formatMoney(total)}</p>
                    <div class="d-flex justify-content-center gap-2">
                        <a href="${data.url_factura}" target="_blank" class="btn btn-primary btn-sm">
                            <i class="bi bi-printer me-1"></i> Imprimir Ticket
                        </a>
                    </div>
                `,
                showConfirmButton: true,
                confirmButtonText: 'Nueva Venta',
                confirmButtonColor: '#4f46e5'
            }).then(() => {
                clearCart();
                // Limpiar campos cliente
                if (document.getElementById('posClienteNombre')) document.getElementById('posClienteNombre').value = 'Consumidor Final';
                if (document.getElementById('posClienteDoc')) document.getElementById('posClienteDoc').value = '';
                if (document.getElementById('posClienteTel')) document.getElementById('posClienteTel').value = '';
                if (receivedInput) receivedInput.value = '';
            });
        } else {
            Swal.fire({
                icon: 'error',
                title: 'Error al registrar venta',
                text: data.message || 'Ocurrió un inconveniente al procesar la venta.'
            });
        }
    } catch (err) {
        console.error(err);
        Swal.fire({
            icon: 'error',
            title: 'Error de Conexión',
            text: 'No se pudo comunicar con el servidor.'
        });
    } finally {
        if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.innerHTML = '<i class="bi bi-check2-circle me-1"></i> Finalizar Venta';
        }
    }
}
