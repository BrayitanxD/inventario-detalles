<?php
// Front Controller / Enrutador Principal MVC

require_once __DIR__ . '/../app/config/config.php';
require_once __DIR__ . '/../app/config/Database.php';

// Autoload de Clases (Modelos y Controladores)
spl_autoload_register(function ($class) {
    $paths = [
        __DIR__ . '/../app/controllers/' . $class . '.php',
        __DIR__ . '/../app/models/' . $class . '.php'
    ];

    foreach ($paths as $path) {
        if (file_exists($path)) {
            require_once $path;
            return;
        }
    }
});

// Obtener Controlador y Acción
$controllerName = $_GET['c'] ?? '';
$actionName     = $_GET['a'] ?? 'index';

// Si no hay sesión y no se está intentando acceder a Auth, enviar a Login
if (!isLoggedIn() && strtolower($controllerName) !== 'auth') {
    $controllerName = 'auth';
    $actionName     = 'login';
} elseif (empty($controllerName)) {
    $controllerName = 'dashboard';
    $actionName     = 'index';
}

// Formatear nombre de clase: 'producto' -> 'ProductoController'
$controllerClass = ucfirst($controllerName) . 'Controller';

if (class_exists($controllerClass)) {
    $controllerInstance = new $controllerClass();

    if (method_exists($controllerInstance, $actionName)) {
        // Ejecutar la acción
        $controllerInstance->$actionName();
    } else {
        http_response_code(404);
        echo "<h1>Error 404</h1><p>El método '{$actionName}' no existe en '{$controllerClass}'.</p>";
    }
} else {
    http_response_code(404);
    echo "<h1>Error 404</h1><p>El controlador '{$controllerClass}' no fue encontrado.</p>";
}
