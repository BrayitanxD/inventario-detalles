<?php
// Redirección al directorio público
header("Location: public/");
exit;
